//! # `onnx-runtime-ep-cpu`
//!
//! The CPU execution provider for the ORT 2.0 runtime (see `docs/architecture/ORT2.md` §4.4
//! and §54 Phase 1). It implements [`onnx_runtime_ep_api::ExecutionProvider`]
//! and hosts pure-Rust reference kernels for the Phase-1 op set (`MatMul`,
//! `Add`, `Relu`, `Reshape`, `Transpose`, `Gather`, `LayerNormalization`).
//!
//! ## Backends: correctness baseline + SIMD fast path
//!
//! The GEMM hot spot is served through [`backend::CpuBackend`] (`docs/architecture/ORT2.md`
//! §25.2). The **default** backend is a pure-Rust blocked, register-tiled,
//! rayon-parallelized f32 GEMM — the portable, offline correctness baseline that
//! compiles anywhere with no C++/FFI. On supported x86 hosts, the built-in
//! `SimdX86` implementation provides the default fast path. Every backend lives behind the
//! [`onnx_runtime_ep_api::Kernel`] trait, so neither the EP contract nor the
//! session observes which one ran. See [`kernels::matmul`] for the hot spot.
//!
//! ## Shared weight contracts
//!
//! Weight capabilities, leases and binding contracts belong to the common EP API:
//!
//! ```
//! use onnx_runtime_ep_api::{ExecutionProviderCapabilities, WeightHandle};
//! let _: Option<WeightHandle> = None;
//! let _ = ExecutionProviderCapabilities::default();
//! ```
//!
//! The CPU crate does not provide a second contract surface:
//!
//! ```compile_fail
//! use onnx_runtime_ep_cpu::WeightHandle;
//! ```
//!
//! ```compile_fail
//! use onnx_runtime_ep_cpu::weight_offload::weight_handle::WeightHandle;
//! ```
//!
//! ## `unsafe`
//!
//! The default (Generic) path is `unsafe`-minimal: the only `unsafe` is the raw
//! device-buffer access the ep-api contract forces (aligned host
//! `alloc`/`dealloc`, `memcpy`, and strided element reads/writes), each isolated
//! and `SAFETY`-documented. The blocked rayon GEMM itself contains no `unsafe`;
//! all kernel arithmetic is safe Rust operating on
//! dense `Vec<f32>` buffers produced by the two audited accessors in [`kernels`].

// Kernel entry points mirror ONNX operator schemas, whose independent tensors and
// dimensions often exceed Clippy's generic argument-count threshold.
#![allow(clippy::too_many_arguments)]

pub mod backend;
pub mod backend_ab;
pub mod core_topology;
pub mod decode_affinity;
pub mod decode_numa;
pub mod decode_spmd;
pub mod dispatch_ledger;
pub mod dtype;
pub mod kernels;
#[cfg(all(feature = "mlas", feature = "ops-cnn"))]
pub mod nchwc_layout;
pub mod optimizer;
pub(crate) mod persistent_pool_width;
pub mod provider;
mod resources;
pub mod strided;
pub mod task_runtime;
#[cfg(test)]
pub(crate) mod test_support;
mod trace;
pub mod weight_offload;

pub use backend::CpuBackend;
pub use dispatch_ledger::{Backend as DispatchBackend, KernelFamily, effective_backend};
pub use kernels::{CpuOpDescriptor, build_cpu_registry_with_descriptors, supported_dtypes_for_op};
pub use optimizer::{
    ConvBatchNormActivationFusion, MatMulNBitsBiasFusion, ProjectionFusion, SiblingProjectionMerge,
    cpu_optimization_passes,
};
pub use provider::CpuExecutionProvider;
pub use resources::{
    CpuCacheRetention, CpuMemoryResources, CpuWeightCacheLimits, DerivedWeightMemory,
};
pub use weight_offload::placement::{
    GpuLayersOverrideReport, HostFallbackReason, IqFormat, LayerPlacement, LayerWeightRegions,
    Placement, PlacementError, PlacementPlan, QuantTileFormat, RegionPlacement, SnappedTileSize,
    TileSizeError, plan_placement, snap_transfer_tile_bytes,
};
pub use weight_offload::{
    LinuxProcessMemoryStats, WEIGHT_OFFLOAD_ENV, WEIGHT_OFFLOAD_HOST_BYTES_ENV,
    WeightOffloadLayerStats, WeightOffloadStats, weight_offload_stats,
};

pub use kernels::selection::non_max_suppression;
pub use kernels::slice::{SliceAxisPlan, slice_axes_steps, slice_plan};

pub use kernels::group_query_attention::{present_inplace_count, present_inplace_half_count};
pub use kernels::matmul_nbits::bound_process_to_decode_budget;
pub use kernels::matmul_nbits::set_decode_thread_budget;
pub use kernels::matmul_nbits::with_decode_pool_scope;
pub use kernels::matmul_nbits::{
    mlas_sqnbit_packed_live_bytes, nbits_decode_f32_retention_candidate,
    planned_nbits_node_retained_bytes, planned_nbits_retained_bytes,
};
// Retention forecasting does not replace actual derived-weight admission.
pub use kernels::matmul::weight_transpose_cache_predicted_bytes;
// #1056: the node-owned `MatMulPrepack::dense` widened-f32 cache is the fourth
// resident, weight-scaled buffer brought under the plan. The plan budgets
// `matmul_dense_cache_predicted_bytes` and, when it does not fit, declines it via
// CpuCacheRetention (kernels then widen per call and retain
// nothing, byte-identical output).
pub use kernels::matmul::matmul_dense_cache_predicted_bytes;
// Immutable reference packs remain node-owned; accumulator scratch belongs to
// the shared execution workspace, not a process-global retention budget.
pub use kernels::qlinear_matmul::{qlinear_packed_b_live_bytes, qlinear_packed_b_predicted_bytes};

#[cfg(test)]
mod feature_default_guard {
    /// `mlas` must stay off by default.
    ///
    /// The vendored MLAS kernels are a research/reference arm, not what ships.
    /// This matters beyond a build flag: `bench_generic` used to *require* the
    /// feature, so every published A/B ratio measured the reference arm while
    /// being read as a production number, and the production pure-Rust softmax
    /// turned out to be about 9x ORT rather than the ~1.0 the tables showed.
    /// If a default build ever links MLAS again, the same class of mistake
    /// becomes possible again, so fail loudly here.
    ///
    /// Resolved from the **manifest**, not from `cfg!`. Cargo features are
    /// additive and indistinguishable at `cfg` time, so `!cfg!(feature =
    /// "mlas")` cannot tell "`mlas` became a default" from "`mlas` was
    /// requested on the command line": it passed in the shipped configuration
    /// (where nothing could have gone wrong yet) and *failed* in the research
    /// one (where nothing is wrong at all), which is the opposite of what this
    /// guard is for. The manifest answers the actual policy question in every
    /// configuration, including `--features mlas`.
    ///
    /// `crates/onnx-runtime-ep-cpu-plugin/tests/default_artifacts_are_mlas_free.rs`
    /// makes the same statement about the shipped cdylib, its resolved
    /// dependency graph and the wheel. This one is here so that editing *this*
    /// crate's `Cargo.toml` and running `cargo test -p onnx-runtime-ep-cpu`
    /// is enough to catch it.
    #[test]
    fn mlas_is_not_a_default_feature() {
        const MANIFEST: &str = include_str!("../Cargo.toml");

        let default = feature_list(MANIFEST, "default");
        assert!(
            !default.is_empty(),
            "probe read no `default` features, so the assertions below would \
             pass vacuously"
        );
        // Transitive: `default` contains the `full` umbrella, so a `full` that
        // gained MLAS would activate it for every consumer without the word
        // `default` appearing anywhere near the change.
        let mut reachable = default.clone();
        let mut frontier = default;
        while let Some(feature) = frontier.pop() {
            for implied in feature_list(MANIFEST, &feature) {
                if !reachable.contains(&implied) {
                    reachable.push(implied.clone());
                    frontier.push(implied);
                }
            }
        }
        // Substring, not `== "mlas"`: `dep:mlas-sys` and
        // `onnx-runtime-ep-cpu/mlas` reach the reference just as well, and
        // nothing else in this workspace is named after MLAS.
        let offenders: Vec<&String> = reachable
            .iter()
            .filter(|f| f.to_ascii_lowercase().contains("mlas"))
            .collect();
        assert!(
            offenders.is_empty(),
            "the default feature closure of onnx-runtime-ep-cpu reaches the \
             MLAS reference through {offenders:?}: production would then ship \
             MLAS and every benchmark arm label would be wrong"
        );
    }

    /// Members of a `name = [...]` feature list, or empty when there is none.
    ///
    /// Deliberately a five-line scan rather than a TOML dependency: this runs
    /// against one hand-written file whose shape is fixed by
    /// `feature_lists_are_read_not_guessed`.
    fn feature_list(manifest: &str, name: &str) -> Vec<String> {
        // Find `name = [` at the start of a line, tolerating any spacing around
        // the `=`. Anchoring on one exact spelling would let a reformat turn a
        // populated feature into a silently empty one, which is the direction
        // this guard must never fail in.
        let start = manifest.lines().enumerate().find_map(|(i, line)| {
            let rest = line.strip_prefix(name)?.trim_start();
            let rest = rest.strip_prefix('=')?.trim_start();
            rest.starts_with('[')
                .then(|| manifest.lines().take(i).map(|l| l.len() + 1).sum::<usize>())
        });
        let Some(start) = start else {
            return Vec::new();
        };
        let open = manifest[start..].find('[').expect("array opens") + start;
        let close = manifest[open..].find(']').expect("array closes") + open;
        manifest[open + 1..close]
            .split(',')
            .map(|item| item.trim().trim_matches('"').trim().to_string())
            .filter(|item| !item.is_empty() && !item.starts_with('#'))
            .collect()
    }

    /// The guard above is a filter over text; a filter that reads nothing
    /// passes every assertion built on it. This is its positive control.
    #[test]
    fn feature_lists_are_read_not_guessed() {
        const MANIFEST: &str = include_str!("../Cargo.toml");
        assert!(
            feature_list(MANIFEST, "default").contains(&"full".to_string()),
            "the manifest reader must see `default = [\"full\"]`"
        );
        assert!(
            feature_list(MANIFEST, "full").contains(&"ops-core".to_string()),
            "the manifest reader must see through the multi-line `full` umbrella"
        );
        assert!(
            feature_list(MANIFEST, "mlas").contains(&"dep:mlas-sys".to_string()),
            "the manifest still has to declare the opt-in research feature"
        );
        assert!(
            feature_list(MANIFEST, "no-such-feature").is_empty(),
            "an absent feature must read as empty, not panic"
        );

        // The transitive walk must actually catch MLAS reaching `default`
        // through the umbrella, which is the regression this guard exists for.
        let synthetic =
            "\ndefault = [\"full\"]\nfull = [\"ops-core\", \"mlas\"]\nmlas = [\"dep:mlas-sys\"]\n";
        assert!(
            feature_list(synthetic, "full").iter().any(|f| f == "mlas"),
            "a `full` umbrella that gained MLAS must be visible to the reader"
        );

        // Spacing must not turn a populated feature into an empty one: an
        // empty read is a *pass* for every caller, so the reader has to be
        // insensitive to formatting the manifest is free to change.
        for spelling in [
            "full=[\"mlas\"]",
            "full  =  [\"mlas\"]",
            "full\t= [\"mlas\"]",
        ] {
            let manifest = format!("\n[features]\n{spelling}\n");
            assert_eq!(
                feature_list(&manifest, "full"),
                vec!["mlas".to_string()],
                "`{spelling}` must read the same as the canonical spelling"
            );
        }

        // A feature name must not match as a suffix or a prefix of another.
        let neighbours = "\nnot-full = [\"mlas\"]\nfull-extra = [\"mlas\"]\n";
        assert!(
            feature_list(neighbours, "full").is_empty(),
            "`full` must not be found inside `not-full` or `full-extra`"
        );
    }
}

#[cfg(test)]
mod group_allocation_probe {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::cell::Cell;
    thread_local! {
        static ARMED: Cell<bool> = const { Cell::new(false) };
        static CALLS: Cell<(usize, usize)> = const { Cell::new((0, 0)) };
    }
    fn record(free: bool) {
        if ARMED.with(Cell::get) {
            CALLS.with(|calls| {
                let (a, d) = calls.get();
                calls.set((a + usize::from(!free), d + usize::from(free)));
            });
        }
    }
    struct Counter;
    // Forward unchanged pointers/layouts; observe only constant, drop-free TLS.
    unsafe impl GlobalAlloc for Counter {
        unsafe fn alloc(&self, l: Layout) -> *mut u8 {record(false); unsafe {System.alloc(l)}}
        unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {record(false); unsafe {System.alloc_zeroed(l)}}
        unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 {record(false); unsafe {System.realloc(p,l,n)}}
        unsafe fn dealloc(&self, p: *mut u8, l: Layout) {record(true); unsafe {System.dealloc(p,l)}}
    }
    #[global_allocator]
    static ALLOCATOR: Counter = Counter;
    pub(crate) fn observed(body: impl FnOnce()) -> (usize,usize) {
        struct Disarm;
        impl Drop for Disarm {fn drop(&mut self){ARMED.with(|armed|armed.set(false));}}
        CALLS.with(|calls|calls.set((0,0)));
        ARMED.with(|armed|armed.set(true));
        let guard=Disarm;body();drop(guard);CALLS.with(Cell::get)
    }
}
