//! Derived weight payloads: cache membership is a policy, ownership holds the grant.
//!
//! Flat vectors and native packed panels share admission, reader lifetime,
//! cold-fill and idle-pressure rules. Dense expansion limits remain policy.

use smallvec::{SmallVec, smallvec};
use std::collections::HashMap;
use std::hash::Hash;
use std::sync::{Arc, Mutex, OnceLock};

use onnx_runtime_ep_api::{EpError, Result};
use onnx_runtime_memory_api::MemoryError;

use crate::DerivedWeightMemory;
use crate::resources::{DerivedWeightGrant, IdleWeightCache, WeightAdmission};

pub(super) trait WeightCacheKey: Clone + Eq + Hash + Send + Sync + 'static {
    fn weight_bytes(&self) -> Result<usize>;
}

pub(crate) const DEFAULT_DENSE_WEIGHT_CACHE_BYTES: usize = 256 * 1024 * 1024;
const DENSE_WEIGHT_CACHE_BYTES_ENV: &str = "ONNX_GENAI_CPU_DENSE_WEIGHT_CACHE_BYTES";

pub(crate) fn configured_dense_weight_cache_bytes() -> usize {
    static BYTES: OnceLock<usize> = OnceLock::new();
    *BYTES.get_or_init(|| {
        parse_dense_weight_cache_bytes(std::env::var(DENSE_WEIGHT_CACHE_BYTES_ENV).ok().as_deref())
    })
}

pub(super) fn parse_dense_weight_cache_bytes(value: Option<&str>) -> usize {
    value
        .and_then(|value| value.trim().parse::<usize>().ok())
        .unwrap_or(DEFAULT_DENSE_WEIGHT_CACHE_BYTES)
}

pub(super) struct GrantedWeight<P = Vec<f32>> {
    values: P,
    // Declaration order frees the payload before returning its grant.
    _grant: DerivedWeightGrant,
}

/// A flat-vector owner identity reserves only the Arc control block.
/// Heap elements and their grant can retire while dependent cache keys live;
/// the reserved control block keeps its identity address from being recycled.
#[cfg(feature = "mlas")]
pub(super) struct WeightIdentity<T = f32>(std::sync::Weak<GrantedWeight<Vec<T>>>);
#[cfg(feature = "mlas")]
impl<T> WeightIdentity<T> {
    pub(super) fn of(owner: &Arc<GrantedWeight<Vec<T>>>) -> Self {
        Self(Arc::downgrade(owner))
    }
}
#[cfg(feature = "mlas")]
impl<T> Clone for WeightIdentity<T> {
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}
#[cfg(feature = "mlas")]
impl<T> PartialEq for WeightIdentity<T> {
    fn eq(&self, other: &Self) -> bool {
        self.0.ptr_eq(&other.0)
    }
}
#[cfg(feature = "mlas")]
impl<T> Eq for WeightIdentity<T> {}
#[cfg(feature = "mlas")]
impl<T> Hash for WeightIdentity<T> {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        self.0.as_ptr().hash(state);
    }
}

impl<P> GrantedWeight<P> {
    #[cfg(all(test, feature = "mlas"))]
    pub(super) fn test_into_parts(self) -> (P, DerivedWeightGrant) {
        (self.values, self._grant)
    }
    #[cfg(feature = "mlas")]
    pub(super) fn payload(&self) -> &P {
        &self.values
    }
}
impl<T> GrantedWeight<Vec<T>> {
    pub(super) fn as_slice(&self) -> &[T] {
        &self.values
    }
}

/// Payload ownership supplies both logical extent and actual allocation size.
/// This includes padded/aligned native panels, not just flat numeric vectors.
pub(super) trait WeightPayload: Send + Sync + 'static {
    fn accepts_bytes(bytes: usize) -> bool;
    fn payload_bytes(&self) -> Option<usize>;
    fn allocation_bytes(&self) -> Option<usize>;
}
impl<T: Copy + Send + Sync + 'static> WeightPayload for Vec<T> {
    fn accepts_bytes(bytes: usize) -> bool {
        let unit = std::mem::size_of::<T>();
        unit != 0 && bytes.is_multiple_of(unit)
    }
    fn payload_bytes(&self) -> Option<usize> {
        self.len().checked_mul(std::mem::size_of::<T>())
    }
    fn allocation_bytes(&self) -> Option<usize> {
        self.capacity().checked_mul(std::mem::size_of::<T>())
    }
}
#[cfg(feature = "mlas")]
impl WeightPayload for mlas_sys::PackedB {
    fn accepts_bytes(bytes: usize) -> bool {
        bytes != 0
    }
    fn payload_bytes(&self) -> Option<usize> {
        Some(self.owned_heap_bytes())
    }
    fn allocation_bytes(&self) -> Option<usize> {
        Some(self.owned_heap_bytes())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum WeightCacheStatus {
    Hit,
    MissStored,
    MissNotStored,
}

pub(super) struct WeightSpec<'a, K> {
    key: Option<&'a K>,
    bytes: usize,
    build_peak_bytes: usize,
}

impl<'a, K: WeightCacheKey> WeightSpec<'a, K> {
    pub(super) fn cached(key: &'a K) -> Result<Self> {
        let bytes = key.weight_bytes()?;
        Ok(Self {
            key: Some(key),
            bytes,
            build_peak_bytes: bytes,
        })
    }

    pub(super) fn transient(bytes: usize) -> Self {
        Self {
            key: None,
            bytes,
            build_peak_bytes: bytes,
        }
    }
    /// Upper bound on simultaneously live weight buffers during building.
    /// Only payload bytes remain charged after the operation completes.
    pub(super) fn with_build_peak(mut self, bytes: usize) -> Self {
        self.build_peak_bytes = bytes;
        self
    }
}

// Most consumers hold one projection or an expert's two/three projections.
// Larger groups spill normally; inline capacity is not an admission limit.
pub(super) struct LoadedWeights<P = Vec<f32>> {
    pub(super) weights: SmallVec<[Arc<GrantedWeight<P>>; 3]>,
    pub(super) statuses: SmallVec<[WeightCacheStatus; 3]>,
}

pub(super) enum WeightLoad<P = Vec<f32>> {
    Ready(LoadedWeights<P>),
    Declined(MemoryError),
}

pub(super) struct WeightCache<K, P = Vec<f32>> {
    max_bytes: usize,
    memory: DerivedWeightMemory,
    inner: Arc<Mutex<CacheState<K, P>>>,
    // Cold fills serialize separately: accountant callbacks and decoding never
    // run under the payload lock. Warm hits do not acquire this gate.
    fill: Mutex<()>,
}

struct CacheState<K, P> {
    used_bytes: usize,
    tick: u64,
    entries: HashMap<K, CacheEntry<P>>,
    #[cfg(test)]
    hits: usize,
    #[cfg(test)]
    builds: usize,
}

struct CacheEntry<P> {
    value: Arc<GrantedWeight<P>>,
    bytes: usize,
    last_used: u64,
}

impl<K, P> Default for CacheState<K, P> {
    fn default() -> Self {
        Self {
            used_bytes: 0,
            tick: 0,
            entries: HashMap::new(),
            #[cfg(test)]
            hits: 0,
            #[cfg(test)]
            builds: 0,
        }
    }
}

impl<K: WeightCacheKey, P: WeightPayload> Default for WeightCache<K, P> {
    fn default() -> Self {
        Self::new(
            DerivedWeightMemory::default(),
            configured_dense_weight_cache_bytes(),
        )
    }
}

impl<K: WeightCacheKey, P: WeightPayload> WeightCache<K, P> {
    pub(super) fn new(memory: DerivedWeightMemory, max_bytes: usize) -> Self {
        let inner = Arc::new(Mutex::new(CacheState::default()));
        if max_bytes != 0 {
            memory.register_idle_cache(&inner);
        }
        Self {
            max_bytes,
            memory,
            inner,
            fill: Mutex::new(()),
        }
    }

    #[cfg(test)]
    pub(super) fn with_limit(limit: usize) -> Self {
        Self::new(DerivedWeightMemory::default(), limit)
    }

    #[cfg(test)]
    pub(super) fn with_limit_and_memory(limit: usize, memory: DerivedWeightMemory) -> Self {
        Self::new(memory, limit)
    }

    pub(super) fn byte_limit(&self) -> usize {
        self.max_bytes
    }

    /// Cold-path query for the vector last-hit slot. A single member needs no
    /// recency update; multi-entry consumers keep the canonical lookup path.
    pub(super) fn has_single_entry(&self) -> bool {
        self.inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .entries
            .len()
            == 1
    }

    /// A single warm reader needs no group containers or accounting callbacks.
    pub(super) fn get(&self, key: &K) -> Option<Arc<GrantedWeight<P>>> {
        let mut inner = self
            .inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        inner.tick = inner.tick.wrapping_add(1);
        let tick = inner.tick;
        let entry = inner.entries.get_mut(key)?;
        entry.last_used = tick;
        let value = entry.value.clone();
        #[cfg(test)]
        {
            inner.hits = inner.hits.saturating_add(1);
        }
        Some(value)
    }

    fn lookup(&self, specs: &[WeightSpec<'_, K>]) -> SmallVec<[Option<Arc<GrantedWeight<P>>>; 3]> {
        let mut inner = self
            .inner
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let values: SmallVec<[_; 3]> = specs
            .iter()
            .map(|spec| {
                spec.key
                    .and_then(|key| inner.entries.get(key))
                    .map(|entry| Arc::clone(&entry.value))
            })
            .collect();
        if values.iter().all(Option::is_some) {
            for spec in specs {
                inner.tick = inner.tick.wrapping_add(1);
                let tick = inner.tick;
                if let Some(entry) = spec.key.and_then(|key| inner.entries.get_mut(key)) {
                    entry.last_used = tick;
                }
            }
            #[cfg(test)]
            {
                inner.hits = inner.hits.saturating_add(values.len());
            }
        }
        values
    }

    fn complete_weights(
        values: SmallVec<[Option<Arc<GrantedWeight<P>>>; 3]>,
    ) -> SmallVec<[Arc<GrantedWeight<P>>; 3]> {
        let complete = |value: Option<Arc<GrantedWeight<P>>>| {
            value.expect("every dense projection hit or built successfully")
        };
        if values.spilled() {
            // Vec's owning map can reuse this heap buffer for equal-sized
            // Option<Arc>/Arc elements. SmallVec's iterator cannot transfer it
            // to a new SmallVec, so preserve the existing spill allocation.
            SmallVec::from_vec(values.into_vec().into_iter().map(complete).collect())
        } else {
            values.into_iter().map(complete).collect()
        }
    }

    fn ready_hits(values: SmallVec<[Option<Arc<GrantedWeight<P>>>; 3]>) -> WeightLoad<P> {
        let statuses = smallvec![WeightCacheStatus::Hit; values.len()];
        WeightLoad::Ready(LoadedWeights {
            weights: Self::complete_weights(values),
            statuses,
        })
    }

    /// Preflight construction peaks before any builder runs. Builders return
    /// exactly sized final payloads; unused scratch allowance returns at the
    /// end of this operation while each live payload keeps only its own grant.
    pub(super) fn load_group_owned(
        &self,
        specs: &[WeightSpec<'_, K>],
        mut build: impl FnMut(usize) -> Result<P>,
    ) -> Result<WeightLoad<P>> {
        for (index, spec) in specs.iter().enumerate() {
            if spec.build_peak_bytes < spec.bytes {
                return Err(EpError::KernelFailed(format!(
                    "dense projection {index} build peak {} is below its {}-byte payload; account for every simultaneously live weight buffer",
                    spec.build_peak_bytes, spec.bytes
                )));
            }
            if spec.bytes > isize::MAX as usize || !P::accepts_bytes(spec.bytes) {
                return Err(EpError::KernelFailed(format!(
                    "dense projection {index} requests {} bytes, which is not an addressable typed buffer; use an element-aligned byte count no larger than isize::MAX",
                    spec.bytes
                )));
            }
            if let Some(key) = spec.key
                && specs[..index]
                    .iter()
                    .any(|earlier| earlier.key == Some(key))
            {
                return Err(EpError::KernelFailed(format!(
                    "dense weight projection group repeats cache key at index {index}; give every projection one unique identity"
                )));
            }
        }
        let keyed = specs.iter().any(|spec| spec.key.is_some());
        let mut values = if keyed {
            self.lookup(specs)
        } else {
            smallvec![None; specs.len()]
        };
        if values.iter().all(Option::is_some) {
            return Ok(Self::ready_hits(values));
        }
        let _fill = keyed.then(|| {
            self.fill
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner())
        });
        if keyed {
            values = self.lookup(specs);
        }
        if values.iter().all(Option::is_some) {
            return Ok(Self::ready_hits(values));
        }
        let required = specs.iter().zip(&values).try_fold(0usize, |total, (spec, value)| {
            if value.is_some() { Ok(total) } else {
                total.checked_add(spec.build_peak_bytes).ok_or_else(|| EpError::KernelFailed("dense weight projection-group byte count overflow; use addressable projection dimensions".into()))
            }
        })?;
        let max_bytes = self.byte_limit();
        let retained_group_bytes = specs
            .iter()
            .filter(|spec| spec.key.is_some())
            .try_fold(0usize, |total, spec| total.checked_add(spec.bytes));
        let retain_new =
            max_bytes != 0 && retained_group_bytes.is_some_and(|bytes| bytes <= max_bytes);
        let cache_growth = specs
            .iter()
            .zip(&values)
            .filter(|(spec, value)| value.is_none() && spec.key.is_some() && retain_new)
            .try_fold(0usize, |total, (spec, _)| {
                total.checked_add(spec.bytes).ok_or_else(|| {
                    EpError::KernelFailed("dense weight cache growth byte count overflow".into())
                })
            })?;
        // Release evicted payloads outside the data lock: the last Arc may
        // return capacity through a third-party accountant callback.
        let evicted = if keyed {
            let mut inner = self
                .inner
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner());
            let mut evicted = Vec::new();
            while inner.used_bytes > max_bytes.saturating_sub(cache_growth) {
                let Some(key) = oldest_unused(&inner, specs, false) else {
                    break;
                };
                evicted.push(remove_entry(&mut inner, &key));
            }
            evicted
        } else {
            Vec::new()
        };
        drop(evicted);
        let mut grant = match self.memory.try_grant(required)? {
            WeightAdmission::Granted(grant) => grant,
            WeightAdmission::Declined(reason) => return Ok(WeightLoad::Declined(reason)),
        };
        let mut statuses = smallvec![WeightCacheStatus::Hit; specs.len()];
        for (index, spec) in specs.iter().enumerate() {
            if values[index].is_some() {
                continue;
            }
            let child = grant.split_off(spec.bytes)?;
            let payload = build(index)?;
            if payload.payload_bytes() != Some(spec.bytes)
                || payload.allocation_bytes() != Some(spec.bytes)
            {
                return Err(EpError::KernelFailed(format!(
                    "dense projection {index} builder returned logical bytes {:?} and allocation bytes {:?} for {} admitted bytes; return an exactly sized typed payload",
                    payload.payload_bytes(),
                    payload.allocation_bytes(),
                    spec.bytes
                )));
            }
            values[index] = Some(Arc::new(GrantedWeight {
                values: payload,
                _grant: child,
            }));
            statuses[index] = if spec.key.is_some() && retain_new {
                WeightCacheStatus::MissStored
            } else {
                WeightCacheStatus::MissNotStored
            };
            #[cfg(test)]
            {
                let mut inner = self
                    .inner
                    .lock()
                    .unwrap_or_else(|poisoned| poisoned.into_inner());
                inner.builds = inner.builds.saturating_add(1);
            }
        }
        let weights = Self::complete_weights(values);
        if keyed {
            let mut inner = self
                .inner
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner());
            for ((spec, value), status) in specs.iter().zip(&weights).zip(&statuses) {
                inner.tick = inner.tick.wrapping_add(1);
                let tick = inner.tick;
                match status {
                    WeightCacheStatus::Hit => {
                        if let Some(entry) = spec.key.and_then(|key| inner.entries.get_mut(key)) {
                            entry.last_used = tick;
                        }
                        #[cfg(test)]
                        {
                            inner.hits = inner.hits.saturating_add(1);
                        }
                    }
                    WeightCacheStatus::MissStored => {
                        let key = spec
                            .key
                            .expect("only keyed projections can be retained")
                            .clone();
                        inner.used_bytes =
                            inner.used_bytes.checked_add(spec.bytes).ok_or_else(|| {
                                EpError::KernelFailed(
                                    "dense cache resident byte count overflow".into(),
                                )
                            })?;
                        inner.entries.insert(
                            key,
                            CacheEntry {
                                value: Arc::clone(value),
                                bytes: spec.bytes,
                                last_used: tick,
                            },
                        );
                    }
                    WeightCacheStatus::MissNotStored => {}
                }
            }
        }
        Ok(WeightLoad::Ready(LoadedWeights { weights, statuses }))
    }

    #[cfg(test)]
    pub(super) fn test_get(&self, key: &K) -> Option<Arc<GrantedWeight<P>>> {
        self.inner
            .lock()
            .unwrap_or_else(|p| p.into_inner())
            .entries
            .get(key)
            .map(|entry| Arc::clone(&entry.value))
    }

    #[cfg(test)]
    pub(super) fn test_first(&self) -> Option<Arc<GrantedWeight<P>>> {
        self.inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .entries
            .values()
            .next()
            .map(|entry| entry.value.clone())
    }

    #[cfg(test)]
    pub(super) fn stats(&self) -> (usize, usize) {
        let inner = self
            .inner
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        (inner.entries.len(), inner.used_bytes)
    }

    #[cfg(test)]
    pub(super) fn activity(&self) -> (usize, usize) {
        let inner = self
            .inner
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        (inner.hits, inner.builds)
    }

    #[cfg(test)]
    pub(super) fn test_get_or_insert_with(
        &self,
        key: &K,
        build: impl FnOnce() -> Result<P>,
    ) -> Result<(Arc<GrantedWeight<P>>, WeightCacheStatus)> {
        let mut build = Some(build);
        match self.load_group_owned(&[WeightSpec::cached(key)?], |_| {
            build.take().expect("single fixture builder")()
        })? {
            WeightLoad::Ready(mut loaded) => {
                Ok((loaded.weights.remove(0), loaded.statuses.remove(0)))
            }
            WeightLoad::Declined(reason) => Err(EpError::Memory(reason)),
        }
    }
}

impl<K: WeightCacheKey, P: Send + Sync + 'static> IdleWeightCache for Mutex<CacheState<K, P>> {
    fn reclaim_idle(&self, want: usize) -> Result<usize> {
        let (retired, released) = {
            let mut inner = self
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner);
            let mut retired = Vec::new();
            let mut released = 0usize;
            while released < want {
                let Some(key) = oldest_unused(&inner, &[], true) else {
                    break;
                };
                let entry = remove_entry(&mut inner, &key);
                released += entry.bytes;
                retired.push(entry);
            }
            (retired, released)
        };
        drop(retired);
        Ok(released)
    }
}

fn oldest_unused<K: WeightCacheKey, P>(
    inner: &CacheState<K, P>,
    specs: &[WeightSpec<'_, K>],
    inactive_only: bool,
) -> Option<K> {
    inner
        .entries
        .iter()
        .filter(|(key, entry)| {
            !specs.iter().any(|spec| spec.key == Some(*key))
                && (!inactive_only || Arc::strong_count(&entry.value) == 1)
        })
        .min_by_key(|(_, entry)| entry.last_used)
        .map(|(key, _)| key.clone())
}

fn remove_entry<K: WeightCacheKey, P>(inner: &mut CacheState<K, P>, key: &K) -> CacheEntry<P> {
    let entry = inner
        .entries
        .remove(key)
        .expect("selected dense-cache victim exists");
    inner.used_bytes = inner
        .used_bytes
        .checked_sub(entry.bytes)
        .expect("dense-cache residency accounts every retained entry");
    entry
}

impl<K: WeightCacheKey, T: Copy + Default + Send + Sync + 'static> WeightCache<K, Vec<T>> {
    /// Preflight every missing projection together, including nonconstant
    /// weights (key=None). A refusal does not invoke any builder.
    pub(super) fn load_group(
        &self,
        specs: &[WeightSpec<'_, K>],
        mut build: impl FnMut(usize, &mut [T]) -> Result<()>,
    ) -> Result<WeightLoad<Vec<T>>> {
        self.load_group_owned(specs, |index| {
            let elements = specs[index].bytes / std::mem::size_of::<T>();
            let mut payload = Vec::new();
            payload.try_reserve_exact(elements).map_err(|error| EpError::KernelFailed(format!(
                "dense weight payload allocation of {} bytes failed: {error}; reduce derived weight dimensions or memory pressure", specs[index].bytes
            )))?;
            payload.resize(elements, T::default());
            build(index, &mut payload)?;
            Ok(payload)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kernels::block_quantized_matmul::{
        BlockFormat, DenseWeightCacheKey, DenseWeightIdentity, packed_tensor_bytes,
    };
    use crate::kernels::testutil::Owned;
    use onnx_runtime_memory_api::{MemoryRole, Tier};
    use onnx_runtime_memory_governor::{
        HolderId, LeaseAccounting, LeaseLedger, LedgerGovernor, MemoryAuthorityId, MemoryGovernor,
        MemoryLease,
    };
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
    use std::sync::{Barrier, Weak};

    fn key(packed: &Owned) -> Arc<DenseWeightCacheKey> {
        let view = packed.view();
        DenseWeightIdentity::default()
            .resolve(&view, BlockFormat::Mxfp4, 4, 1, 0, None, || {
                packed_tensor_bytes(&view)
            })
            .unwrap()
            .key
    }
    fn cached(key: &DenseWeightCacheKey) -> WeightSpec<'_, DenseWeightCacheKey> {
        WeightSpec {
            key: Some(key),
            bytes: 16,
            build_peak_bytes: 16,
        }
    }
    fn memory(limit: u64) -> (LedgerGovernor, DerivedWeightMemory) {
        let governor = LedgerGovernor::new(LeaseLedger::new(0, limit, 0));
        let source = DerivedWeightMemory::governed(&governor, HolderId::new(13)).unwrap();
        (governor, source)
    }
    fn ready(loaded: WeightLoad) -> LoadedWeights {
        match loaded {
            WeightLoad::Ready(ready) => ready,
            WeightLoad::Declined(reason) => panic!("expected grant: {reason}"),
        }
    }

    #[test]
    fn shared_pressure_reclaims_another_dense_cache_without_touching_active_readers() {
        let (governor, source) = memory(32);
        let a = WeightCache::<DenseWeightCacheKey>::new(source.clone(), 32);
        let b = WeightCache::<DenseWeightCacheKey>::new(source.clone(), 32);
        let c = WeightCache::<DenseWeightCacheKey>::new(source, 0);
        let packed_a = Owned::u8(&[4], &[1; 4]);
        let packed_b = Owned::u8(&[4], &[2; 4]);
        let ka = key(&packed_a);
        let kb = key(&packed_b);
        drop(ready(
            a.load_group(&[cached(&ka)], |_, row| {
                row.fill(1.0);
                Ok(())
            })
            .unwrap(),
        ));
        let held = ready(
            b.load_group(&[cached(&kb)], |_, row| {
                row.fill(2.0);
                Ok(())
            })
            .unwrap(),
        );
        assert_eq!(governor.used(Tier::Host), 32);
        let transient = ready(
            c.load_group(&[WeightSpec::transient(16)], |_, row| {
                row.fill(3.0);
                Ok(())
            })
            .unwrap(),
        );
        assert_eq!(a.stats(), (0, 0));
        assert_eq!(b.stats(), (1, 16));
        assert_eq!(held.weights[0].as_slice(), &[2.0; 4]);
        assert_eq!(transient.weights[0].as_slice(), &[3.0; 4]);
        assert_eq!(governor.used(Tier::Host), 32);
        let mut built = false;
        assert!(matches!(
            c.load_group(&[WeightSpec::transient(16)], |_, _| {
                built = true;
                Ok(())
            })
            .unwrap(),
            WeightLoad::Declined(_)
        ));
        assert!(!built);
        drop(transient);
        drop(b);
        assert_eq!(
            governor.used(Tier::Host),
            16,
            "active reader retains the exact grant after its cache drops"
        );
        drop(held);
        assert_eq!(governor.used(Tier::Host), 0);
    }

    #[test]
    fn kv_lease_pressure_reclaims_idle_cpu_weights_across_sources_on_the_same_authority() {
        let (governor, first_source) = memory(36);
        let second_source = DerivedWeightMemory::governed(&governor, HolderId::new(14)).unwrap();
        assert!(first_source.supports_pressure_reclaim());
        assert!(second_source.supports_pressure_reclaim());
        let mut kv = governor
            .reserve(Tier::Host, 4, MemoryRole::KvCache, HolderId::new(2))
            .unwrap();
        let a = WeightCache::<DenseWeightCacheKey>::new(first_source, 16);
        let b = WeightCache::<DenseWeightCacheKey>::new(second_source, 16);
        let pa = Owned::u8(&[4], &[1; 4]);
        let pb = Owned::u8(&[4], &[2; 4]);
        let ka = key(&pa);
        let kb = key(&pb);
        drop(ready(
            a.load_group(&[cached(&ka)], |_, row| {
                row.fill(1.0);
                Ok(())
            })
            .unwrap(),
        ));
        drop(ready(
            b.load_group(&[cached(&kb)], |_, row| {
                row.fill(2.0);
                Ok(())
            })
            .unwrap(),
        ));
        let active = b.test_get(&kb).unwrap();
        assert_eq!(governor.used(Tier::Host), 36);
        kv.grow(8).unwrap();
        assert_eq!(a.stats(), (0, 0));
        assert_eq!(b.stats(), (1, 16));
        assert_eq!(kv.bytes(), 12);
        assert_eq!(governor.used(Tier::Host), 28);
        assert!(matches!(
            kv.grow(16),
            Err(MemoryError::TierExhausted { .. })
        ));
        assert_eq!(
            kv.bytes(),
            12,
            "failed growth cannot alter the live KV lease"
        );
        assert_eq!(active.as_slice(), &[2.0; 4]);
        drop(active);
        kv.grow(16).unwrap();
        assert_eq!(b.stats(), (0, 0));
        assert_eq!(kv.bytes(), 28);
        assert_eq!(governor.used(Tier::Host), 28);
        let sibling = kv.reserve_sibling(8).unwrap();
        assert_eq!(governor.used(Tier::Host), 36);
        drop(sibling);
        drop(kv);
        assert_eq!(governor.used(Tier::Host), 0);
    }

    #[test]
    fn shared_pressure_concurrent_cold_fills_keep_active_payloads_and_do_not_take_foreign_fill_gates()
     {
        #[derive(Clone, Copy, PartialEq, Eq, Hash)]
        struct Key(usize);
        impl WeightCacheKey for Key {
            fn weight_bytes(&self) -> Result<usize> {
                Ok(16)
            }
        }
        let (governor, source) = memory(16);
        let caches = [
            WeightCache::<Key>::new(source.clone(), 16),
            WeightCache::<Key>::new(source, 16),
        ];
        let barrier = Barrier::new(2);
        let admitted = AtomicUsize::new(0);
        let declined = AtomicUsize::new(0);
        std::thread::scope(|scope| {
            for (worker, cache) in caches.iter().enumerate() {
                let barrier = &barrier;
                let admitted = &admitted;
                let declined = &declined;
                let governor = &governor;
                scope.spawn(move || {
                    for round in 0..32 {
                        let key = Key(2 * round + worker);
                        barrier.wait();
                        let loaded = cache
                            .load_group(&[WeightSpec::cached(&key).unwrap()], |_, row| {
                                row.fill(key.0 as f32);
                                Ok(())
                            })
                            .unwrap();
                        match &loaded {
                            WeightLoad::Ready(ready) => {
                                admitted.fetch_add(1, Ordering::Relaxed);
                                assert_eq!(ready.weights[0].as_slice(), &[key.0 as f32; 4]);
                            }
                            WeightLoad::Declined(_) => {
                                declined.fetch_add(1, Ordering::Relaxed);
                            }
                        }
                        assert!(governor.used(Tier::Host) <= 16);
                        // Both results stay alive until both allocations finish:
                        // a successful payload must not fund the competing miss.
                        barrier.wait();
                        drop(loaded);
                        barrier.wait();
                    }
                });
            }
        });
        assert_eq!(admitted.load(Ordering::Relaxed), 32);
        assert_eq!(declined.load(Ordering::Relaxed), 32);
        assert_eq!(governor.used(Tier::Host), 16);
        drop(caches);
        assert_eq!(governor.used(Tier::Host), 0);
    }

    #[test]
    fn shared_pressure_keeps_partial_hit_groups_pinned_and_respects_authorities() {
        let (governor, source) = memory(32);
        let a = WeightCache::<DenseWeightCacheKey>::new(source.clone(), 64);
        let other = WeightCache::<DenseWeightCacheKey>::new(source, 64);
        let p = [
            Owned::u8(&[4], &[1; 4]),
            Owned::u8(&[4], &[2; 4]),
            Owned::u8(&[4], &[3; 4]),
        ];
        let keys: Vec<_> = p.iter().map(key).collect();
        drop(ready(
            a.load_group(&[cached(&keys[0])], |_, row| {
                row.fill(1.0);
                Ok(())
            })
            .unwrap(),
        ));
        drop(ready(
            other
                .load_group(&[cached(&keys[1])], |_, row| {
                    row.fill(2.0);
                    Ok(())
                })
                .unwrap(),
        ));
        let (foreign_governor, foreign_source) = memory(16);
        let foreign = WeightCache::<DenseWeightCacheKey>::new(foreign_source.clone(), 16);
        drop(ready(
            foreign
                .load_group(&[cached(&keys[2])], |_, row| {
                    row.fill(9.0);
                    Ok(())
                })
                .unwrap(),
        ));
        let hit = a.test_get(&keys[0]).unwrap();
        let loaded = ready(
            a.load_group(&[cached(&keys[0]), cached(&keys[2])], |index, row| {
                assert_eq!(index, 1);
                row.fill(3.0);
                Ok(())
            })
            .unwrap(),
        );
        assert!(Arc::ptr_eq(&hit, &loaded.weights[0]));
        assert_eq!(other.stats(), (0, 0));
        assert_eq!(foreign.stats(), (1, 16));
        assert_eq!(governor.used(Tier::Host), 32);
        assert_eq!(foreign_governor.used(Tier::Host), 16);
        drop(loaded);
        drop(hit);
        let pins = foreign.test_get(&keys[2]).unwrap();
        assert!(
            matches!(
                foreign_source.try_grant(16).unwrap(),
                WeightAdmission::Declined(_)
            ),
            "another authority cannot evict idle entries from these books"
        );
        drop(pins);
        assert_eq!(a.stats(), (2, 32));
        drop(a);
        drop(foreign);
        assert_eq!(governor.used(Tier::Host), 0);
        assert_eq!(foreign_governor.used(Tier::Host), 0);
    }

    #[test]
    fn owned_builder_peak_refunds_scratch_and_keeps_only_the_live_payload_charge() {
        let packed = Owned::u8(&[4], &[1; 4]);
        let key = key(&packed);
        let (governor, source) = memory(32);
        let cache = WeightCache::<DenseWeightCacheKey>::new(source, 16);
        let spec = cached(&key).with_build_peak(32);
        let mut loaded = ready(
            cache
                .load_group_owned(&[spec], |_| {
                    assert_eq!(governor.used(Tier::Host), 32);
                    let source = vec![2.0f32; 4];
                    let placed = source.clone();
                    assert_eq!(governor.used(Tier::Host), 32);
                    Ok(placed)
                })
                .unwrap(),
        );
        assert_eq!(governor.used(Tier::Host), 16);
        let live = loaded.weights.remove(0);
        drop(loaded);
        let other = governor
            .reserve(Tier::Host, 16, MemoryRole::KvCache, HolderId::new(7))
            .unwrap();
        let hit = ready(
            cache
                .load_group_owned(&[cached(&key).with_build_peak(32)], |_| {
                    panic!("warm payload must not rebuild or request a second peak allowance")
                })
                .unwrap(),
        );
        assert!(Arc::ptr_eq(&live, &hit.weights[0]));
        assert_eq!(governor.used(Tier::Host), 32);
        drop(hit);
        drop(other);
        drop(cache);
        assert_eq!(governor.used(Tier::Host), 16);
        drop(live);
        assert_eq!(governor.used(Tier::Host), 0);
    }

    #[test]
    fn owned_builder_refusal_and_invalid_payloads_leave_no_reservation_or_cache_entry() {
        let packed = Owned::u8(&[4], &[1; 4]);
        let key = key(&packed);
        let (governor, source) = memory(16);
        let cache = WeightCache::<DenseWeightCacheKey>::new(source, 16);
        assert!(matches!(
            cache
                .load_group_owned(&[cached(&key).with_build_peak(32)], |_| {
                    panic!("placement peak must be admitted before invoking the builder")
                })
                .unwrap(),
            WeightLoad::Declined(_)
        ));
        assert_eq!(governor.used(Tier::Host), 0);
        for mode in 0..3 {
            let failure = cache
                .load_group_owned(&[cached(&key)], |_| {
                    if mode == 0 {
                        return Ok(vec![1.0; 3]);
                    }
                    if mode == 1 {
                        let mut v = Vec::with_capacity(8);
                        v.resize(4, 1.0);
                        return Ok(v);
                    }
                    Err(EpError::KernelFailed("fixture decode failure".into()))
                })
                .err()
                .expect("invalid builder result must fail");
            assert!(failure.to_string().contains(if mode == 2 {
                "fixture decode failure"
            } else {
                "exactly sized typed payload"
            }));
            assert_eq!(governor.used(Tier::Host), 0);
            assert_eq!(cache.stats(), (0, 0));
        }
        let failure = cache
            .load_group_owned(&[cached(&key).with_build_peak(15)], |_| {
                panic!("an underspecified construction peak must not run")
            })
            .err()
            .unwrap();
        assert!(failure.to_string().contains("below its 16-byte payload"));
        assert_eq!(governor.used(Tier::Host), 0);
    }

    #[test]
    fn invalid_buffer_sizes_are_rejected_before_any_builder_or_grant() {
        let cache = WeightCache::<DenseWeightCacheKey>::default();
        for bytes in [3, isize::MAX as usize + 1] {
            let failure = cache
                .load_group(
                    &[WeightSpec {
                        key: None,
                        bytes,
                        build_peak_bytes: bytes,
                    }],
                    |_, _| panic!("invalid buffer must not be allocated"),
                )
                .err()
                .expect("invalid f32 buffer size");
            assert!(failure.to_string().contains("addressable typed buffer"));
        }
    }

    #[test]
    fn separate_kernel_caches_share_capacity_and_evicted_active_arcs_keep_the_charge() {
        let p1 = Owned::u8(&[4], &[1; 4]);
        let p2 = Owned::u8(&[4], &[2; 4]);
        let k1 = key(&p1);
        let k2 = key(&p2);
        let (governor, source) = memory(16);
        let first = WeightCache::<DenseWeightCacheKey>::new(source.clone(), 16);
        let second = WeightCache::<DenseWeightCacheKey>::new(source, 1024);
        let live = ready(
            first
                .load_group(&[cached(&k1)], |_, output| {
                    output.fill(1.0);
                    Ok(())
                })
                .unwrap(),
        );
        assert_eq!(governor.used(Tier::Host), 16);
        assert!(matches!(
            first
                .load_group(&[cached(&k2)], |_, _| panic!(
                    "active eviction must not create grant headroom"
                ))
                .unwrap(),
            WeightLoad::Declined(_)
        ));
        assert_eq!(
            first.stats(),
            (0, 0),
            "LRU membership is gone while caller ownership remains"
        );
        assert_eq!(live.weights[0].as_slice(), &[1.0; 4]);
        assert_eq!(governor.used(Tier::Host), 16);
        drop(first);
        let mut builds = 0;
        let denied = second
            .load_group(&[cached(&k2)], |_, output| {
                builds += 1;
                output.fill(2.0);
                Ok(())
            })
            .unwrap();
        assert!(matches!(
            denied,
            WeightLoad::Declined(MemoryError::TierExhausted { requested: 16, .. })
        ));
        assert_eq!(builds, 0, "refusal must precede dense allocation");
        assert_eq!(
            governor.used(Tier::Host),
            16,
            "eviction must not return a caller's live payload"
        );
        drop(live);
        assert_eq!(governor.used(Tier::Host), 0);
        let loaded = ready(
            second
                .load_group(&[cached(&k2)], |_, output| {
                    output.fill(2.0);
                    Ok(())
                })
                .unwrap(),
        );
        drop(loaded);
        assert_eq!(
            governor.used(Tier::Host),
            16,
            "retained data still owns its exact grant"
        );
        drop(second);
        assert_eq!(governor.used(Tier::Host), 0);
    }

    #[test]
    fn complete_projection_group_is_preflighted_before_any_builder() {
        let (governor, source) = memory(31);
        let cache = WeightCache::<DenseWeightCacheKey>::new(source, 1024);
        let specs = [
            WeightSpec {
                key: None,
                bytes: 16,
                build_peak_bytes: 16,
            },
            WeightSpec {
                key: None,
                bytes: 16,
                build_peak_bytes: 16,
            },
        ];
        let mut builds = 0;
        assert!(matches!(
            cache
                .load_group(&specs, |_, output| {
                    builds += 1;
                    output.fill(1.0);
                    Ok(())
                })
                .unwrap(),
            WeightLoad::Declined(MemoryError::TierExhausted { requested: 32, .. })
        ));
        assert_eq!(builds, 0);
        assert_eq!(governor.used(Tier::Host), 0);
        assert_eq!(cache.stats(), (0, 0));
        let (governor, source) = memory(32);
        let cache = WeightCache::<DenseWeightCacheKey>::new(source, 1024);
        let mut loaded = ready(
            cache
                .load_group(&specs, |_, output| {
                    output.fill(1.0);
                    Ok(())
                })
                .unwrap(),
        );
        assert_eq!(governor.used(Tier::Host), 32);
        drop(loaded.weights.pop());
        assert_eq!(
            governor.used(Tier::Host),
            16,
            "partitioned grant returns exactly the released projection"
        );
        drop(loaded);
        assert_eq!(governor.used(Tier::Host), 0);
    }

    #[test]
    fn larger_projection_groups_keep_atomic_admission_and_reader_lifetimes() {
        use crate::kernels::testutil::RecordingGovernor;
        // Four members exercise the dynamic path beyond the usual expert set.
        let packed: Vec<_> = (1..=4).map(|n| Owned::u8(&[4], &[n; 4])).collect();
        let keys: Vec<_> = packed.iter().map(key).collect();
        let specs: Vec<_> = keys.iter().map(|key| cached(key)).collect();
        let books = RecordingGovernor::new_host(63);
        let cache =
            WeightCache::<DenseWeightCacheKey>::new(books.weight_memory(HolderId::new(13)), 64);
        assert!(matches!(
            cache
                .load_group(&specs, |_, _| panic!(
                    "whole-group refusal precedes every builder"
                ))
                .unwrap(),
            WeightLoad::Declined(MemoryError::TierExhausted { requested: 64, .. })
        ));
        assert_eq!(books.used(Tier::Host), 0);
        assert_eq!(cache.stats(), (0, 0));

        let books = RecordingGovernor::new_host(64);
        let cache =
            WeightCache::<DenseWeightCacheKey>::new(books.weight_memory(HolderId::new(13)), 64);
        let error = cache
            .load_group(&specs, |index, output| {
                if index == 3 {
                    return Err(EpError::KernelFailed(
                        "fourth projection rejected its block".into(),
                    ));
                }
                output.fill(index as f32 + 1.);
                Ok(())
            })
            .err()
            .expect("last builder must fail");
        assert!(error.to_string().contains("fourth projection"));
        assert_eq!(cache.stats(), (0, 0));
        assert_eq!(books.used(Tier::Host), 0, "all earlier slices must refund");

        let loaded = ready(
            cache
                .load_group(&specs, |index, output| {
                    output.fill(index as f32 + 1.);
                    Ok(())
                })
                .unwrap(),
        );
        assert_eq!(cache.stats(), (4, 64));
        assert_eq!(books.used(Tier::Host), 64);
        let before = (books.claims(), books.releases());
        let warm = ready(
            cache
                .load_group(&specs, |_, _| panic!("warm group must not rebuild"))
                .unwrap(),
        );
        assert_eq!((books.claims(), books.releases()), before);
        assert_eq!(warm.weights.len(), 4);
        for (index, (cold, hit)) in loaded.weights.iter().zip(&warm.weights).enumerate() {
            assert!(Arc::ptr_eq(cold, hit));
            assert_eq!(hit.as_slice(), &[index as f32 + 1.; 4]);
        }
        assert!(
            warm.statuses
                .iter()
                .all(|status| *status == WeightCacheStatus::Hit)
        );
        drop(cache);
        drop(loaded);
        assert_eq!(
            books.used(Tier::Host),
            64,
            "live readers outlast cache membership"
        );
        drop(warm);
        assert_eq!(books.used(Tier::Host), 0);
    }

    #[test]
    fn partial_rekey_replaces_only_missing_projection_under_an_exact_group_budget() {
        let p1 = Owned::u8(&[4], &[1; 4]);
        let p2 = Owned::u8(&[4], &[2; 4]);
        let p3 = Owned::u8(&[4], &[3; 4]);
        let k1 = key(&p1);
        let k2 = key(&p2);
        let k3 = key(&p3);
        let (governor, source) = memory(32);
        let cache = WeightCache {
            max_bytes: 32,
            ..WeightCache::<DenseWeightCacheKey>::new(source, 1024)
        };
        let first = ready(
            cache
                .load_group(&[cached(&k1), cached(&k2)], |index, output| {
                    output.fill(index as f32 + 1.0);
                    Ok(())
                })
                .unwrap(),
        );
        let retained = Arc::clone(&first.weights[0]);
        drop(first);
        let mut builds = 0;
        let second = ready(
            cache
                .load_group(&[cached(&k1), cached(&k3)], |_, output| {
                    builds += 1;
                    output.fill(3.0);
                    Ok(())
                })
                .unwrap(),
        );
        assert_eq!(builds, 1);
        assert!(Arc::ptr_eq(&retained, &second.weights[0]));
        assert_eq!(
            second.statuses.as_slice(),
            [WeightCacheStatus::Hit, WeightCacheStatus::MissStored]
        );
        assert_eq!(governor.used(Tier::Host), 32);
        assert_eq!(cache.stats(), (2, 32));
        let warm = ready(
            cache
                .load_group(&[cached(&k1), cached(&k3)], |_, _| {
                    panic!("warm group must not rebuild")
                })
                .unwrap(),
        );
        assert!(
            warm.statuses
                .iter()
                .all(|status| *status == WeightCacheStatus::Hit)
        );
    }

    #[test]
    fn failed_group_builder_refunds_all_slices_and_publishes_no_partial_group() {
        let p1 = Owned::u8(&[4], &[1; 4]);
        let p2 = Owned::u8(&[4], &[2; 4]);
        let k1 = key(&p1);
        let k2 = key(&p2);
        let (governor, source) = memory(32);
        let cache = WeightCache::<DenseWeightCacheKey>::new(source, 1024);
        let failure = cache
            .load_group(&[cached(&k1), cached(&k2)], |index, output| {
                if index == 0 {
                    output.fill(1.0);
                    Ok(())
                } else {
                    Err(EpError::KernelFailed(
                        "fc2 projection decoder rejected the test block".into(),
                    ))
                }
            })
            .err()
            .expect("second projection must fail");
        assert!(failure.to_string().contains("fc2 projection"));
        assert_eq!(governor.used(Tier::Host), 0);
        assert_eq!(cache.stats(), (0, 0));
    }

    #[test]
    fn simultaneous_group_misses_are_single_flight_and_do_not_overclaim() {
        let p1 = Owned::u8(&[4], &[1; 4]);
        let p2 = Owned::u8(&[4], &[2; 4]);
        let k1 = key(&p1);
        let k2 = key(&p2);
        let (governor, source) = memory(32);
        let cache = Arc::new(WeightCache::<DenseWeightCacheKey>::new(source, 1024));
        let builds = AtomicUsize::new(0);
        let barrier = Barrier::new(4);
        std::thread::scope(|scope| {
            for _ in 0..4 {
                scope.spawn(|| {
                    barrier.wait();
                    let loaded = ready(
                        cache
                            .load_group(&[cached(&k1), cached(&k2)], |index, output| {
                                builds.fetch_add(1, Ordering::Relaxed);
                                output.fill(index as f32 + 1.0);
                                Ok(())
                            })
                            .unwrap(),
                    );
                    assert_eq!(loaded.weights[1].as_slice(), &[2.0; 4]);
                });
            }
        });
        assert_eq!(builds.load(Ordering::Relaxed), 2);
        assert_eq!(governor.used(Tier::Host), 32);
    }

    #[derive(Debug)]
    struct ObservingBooks {
        governor: LedgerGovernor,
        cache: Mutex<Weak<WeightCache<DenseWeightCacheKey>>>,
        blocked: AtomicBool,
        observations: AtomicUsize,
    }
    impl ObservingBooks {
        fn observe(&self) {
            if let Some(cache) = self.cache.lock().unwrap().upgrade() {
                self.observations.fetch_add(1, Ordering::Relaxed);
                if cache.inner.try_lock().is_err() {
                    self.blocked.store(true, Ordering::Relaxed);
                }
            }
        }
    }
    impl LeaseAccounting for ObservingBooks {
        fn authority_id(&self) -> Option<MemoryAuthorityId> {
            Some(self.governor.authority_id(Tier::Host))
        }
        fn release(&self, tier: Tier, bytes: u64) {
            self.observe();
            LeaseAccounting::release(self.governor.ledger().as_ref(), tier, bytes);
        }
        fn try_claim(
            &self,
            tier: Tier,
            bytes: u64,
            role: MemoryRole,
        ) -> std::result::Result<(), MemoryError> {
            self.observe();
            self.governor.ledger().try_claim(tier, bytes, role)
        }
    }
    struct ObservingGovernor(Arc<ObservingBooks>);
    impl MemoryGovernor for ObservingGovernor {
        fn pressure_registry(
            &self,
            tier: Tier,
        ) -> Option<onnx_runtime_memory_governor::PressureRegistry> {
            self.0.governor.pressure_registry(tier)
        }
        fn authority_id(&self, tier: Tier) -> MemoryAuthorityId {
            self.0.governor.authority_id(tier)
        }
        fn reserve(
            &self,
            tier: Tier,
            bytes: u64,
            role: MemoryRole,
            holder: HolderId,
        ) -> std::result::Result<MemoryLease, MemoryError> {
            self.0.governor.ledger().try_claim(tier, bytes, role)?;
            Ok(MemoryLease::new(tier, bytes, role, holder, self.0.clone()))
        }
        fn available(&self, tier: Tier) -> u64 {
            self.0.governor.available(tier)
        }
        fn used(&self, tier: Tier) -> u64 {
            self.0.governor.used(tier)
        }
    }
    #[test]
    fn accountant_can_observe_cache_during_claim_and_inactive_reclamation() {
        let books = Arc::new(ObservingBooks {
            governor: LedgerGovernor::new(LeaseLedger::new(0, 16, 0)),
            cache: Mutex::new(Weak::new()),
            blocked: AtomicBool::new(false),
            observations: AtomicUsize::new(0),
        });
        let source =
            DerivedWeightMemory::governed(&ObservingGovernor(books.clone()), HolderId::new(13))
                .unwrap();
        let cache = Arc::new(WeightCache::<DenseWeightCacheKey>::new(source, 1024));
        *books.cache.lock().unwrap() = Arc::downgrade(&cache);
        let p1 = Owned::u8(&[4], &[1; 4]);
        let p2 = Owned::u8(&[4], &[2; 4]);
        let k1 = key(&p1);
        let k2 = key(&p2);
        drop(ready(
            cache
                .load_group(&[cached(&k1)], |_, output| {
                    output.fill(1.0);
                    Ok(())
                })
                .unwrap(),
        ));
        drop(ready(
            cache
                .load_group(&[cached(&k2)], |_, output| {
                    output.fill(2.0);
                    Ok(())
                })
                .unwrap(),
        ));
        assert_eq!(cache.stats(), (1, 16));
        assert_eq!(
            books.observations.load(Ordering::Relaxed),
            3,
            "two issuer requests and one retired payload refund; the authority retries its own books internally"
        );
        assert!(
            !books.blocked.load(Ordering::Relaxed),
            "accounting callbacks must run outside the payload lock"
        );
        let before = books.observations.load(Ordering::Relaxed);
        drop(ready(
            cache
                .load_group(&[cached(&k2)], |_, _| panic!("warm hit must not rebuild"))
                .unwrap(),
        ));
        assert_eq!(
            books.observations.load(Ordering::Relaxed),
            before,
            "warm hits must not consult the grant source"
        );
    }
    #[test]
    fn zero_derived_projection_groups_skip_admission_and_mixed_groups_fund_only_payloads() {
        use crate::kernels::testutil::RecordingGovernor;
        let books = RecordingGovernor::new_host(8);
        let source = books.weight_memory(HolderId::new(13));
        let cache = WeightCache::<DenseWeightCacheKey>::new(source, 0);
        let baseline = (books.claims(), books.releases());
        let mut built = 0;
        for _ in 0..16 {
            let loaded = ready(
                cache
                    .load_group(
                        &[WeightSpec::transient(0), WeightSpec::transient(0)],
                        |_, output| {
                            assert!(output.is_empty());
                            built += 1;
                            Ok(())
                        },
                    )
                    .unwrap(),
            );
            assert_eq!(loaded.weights.len(), 2);
            assert!(loaded.weights.iter().all(|weight| weight.values.is_empty()));
            drop(loaded);
            assert_eq!((books.claims(), books.releases()), baseline);
            assert_eq!(books.used(Tier::Host), 0);
        }
        assert_eq!(
            built, 32,
            "zero-byte results must still be constructed, not silently skipped"
        );
        let loaded = ready(
            cache
                .load_group(
                    &[
                        WeightSpec::transient(0),
                        WeightSpec::transient(8),
                        WeightSpec::transient(0),
                    ],
                    |index, output| {
                        output.fill(index as f32);
                        Ok(())
                    },
                )
                .unwrap(),
        );
        assert_eq!(loaded.weights[1].values, [1., 1.]);
        assert!(loaded.weights[0].values.is_empty() && loaded.weights[2].values.is_empty());
        assert_eq!(books.used(Tier::Host), 8);
        assert_eq!(books.claims(), baseline.0 + 1);
        assert_eq!(books.releases(), baseline.1);
        drop(loaded);
        assert_eq!(books.used(Tier::Host), 0);
        assert_eq!(books.releases(), baseline.1 + 1);

        // Empty final storage does not erase positive construction demand.
        let before_peak = (books.claims(), books.releases());
        let loaded = ready(
            cache
                .load_group_owned(
                    &[WeightSpec {
                        key: None,
                        bytes: 0,
                        build_peak_bytes: 8,
                    }],
                    |_| {
                        assert_eq!(
                            books.used(Tier::Host),
                            8,
                            "construction peak must be funded before building"
                        );
                        let temporary = vec![1.0f32, 2.0];
                        std::hint::black_box(&temporary);
                        Ok(Vec::new())
                    },
                )
                .unwrap(),
        );
        assert!(loaded.weights[0].values.is_empty());
        assert_eq!(
            books.used(Tier::Host),
            0,
            "temporary construction grant returns at the end of the build"
        );
        assert_eq!(
            (books.claims(), books.releases()),
            (before_peak.0 + 1, before_peak.1 + 1)
        );
        drop(loaded);
        assert_eq!(
            (books.claims(), books.releases()),
            (before_peak.0 + 1, before_peak.1 + 1)
        );
        assert_eq!(cache.stats(), (0, 0));
    }
}

#[cfg(test)]
mod allocation_probe {
    use super::*;
    use crate::group_allocation_probe::observed;
    use crate::kernels::testutil::RecordingGovernor;
    use onnx_runtime_memory_api::Tier;
    use onnx_runtime_memory_governor::{HolderId, MemoryGovernor};
    #[derive(Clone,PartialEq,Eq,Hash)]
    struct Key(usize);
    impl WeightCacheKey for Key {fn weight_bytes(&self)->Result<usize>{Ok(16)}}
    #[test]
    fn warm_group_heap_calls() {
        let positive=observed(||drop(std::hint::black_box(Box::new([3u8;1024]))));
        assert!(positive.0>0 && positive.1>0);
        println!("CONTROL allocations={} frees={}",positive.0,positive.1);
        for len in [0usize,1,2,3,4,8] {
            let keys:Vec<_>=(0..len).map(Key).collect();
            let specs:Vec<_>=keys.iter().map(|key|WeightSpec::cached(key).unwrap()).collect();
            let books=RecordingGovernor::new_host((len*16) as u64);
            let cache=WeightCache::<Key>::new(books.weight_memory(HolderId::new(13)),len*16);
            let WeightLoad::Ready(cold)=cache.load_group(&specs,|index,out|{out.fill(index as f32+1.);Ok(())}).unwrap() else {panic!("cold group must fit")};
            assert_eq!(books.used(Tier::Host),(len*16) as u64);
            let before=(books.claims(),books.releases());
            let counts=observed(||{
                for _ in 0..2048 {
                    let WeightLoad::Ready(warm)=cache.load_group(&specs,|_,_|panic!("warm hit must not build")).unwrap() else {panic!("warm group must hit")};
                    assert_eq!(warm.weights.len(),len);
                    for (index,(a,b)) in cold.weights.iter().zip(&warm.weights).enumerate(){
                        assert!(Arc::ptr_eq(a,b));assert_eq!(b.as_slice(),&[index as f32+1.;4]);
                    }
                    assert!(warm.statuses.iter().all(|s|*s==WeightCacheStatus::Hit));
                    std::hint::black_box(&warm);
                }
            });
            assert_eq!((books.claims(),books.releases()),before);
            assert_eq!(cache.stats(),(len,len*16));
            drop(cache);assert_eq!(books.used(Tier::Host),(len*16) as u64);
            drop(cold);assert_eq!(books.used(Tier::Host),0);
            println!("GROUP members={len} iterations=2048 allocations={} frees={} issuer_delta=0 final_used=0",counts.0,counts.1);
        }
    }
}
