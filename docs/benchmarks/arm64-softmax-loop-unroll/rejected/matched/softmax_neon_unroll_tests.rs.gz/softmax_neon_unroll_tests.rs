//! Same-binary control for the ARM64 loop-unrolling candidate.

use super::*;

// Match the public native entry's Result ABI, complete-row validation and
// runtime ISA seam. Only the row body's compile-time unroll parameter differs.
#[inline(never)]
fn original_rows(src: &[f32], dst: &mut [f32], columns: usize) -> onnx_runtime_ep_api::Result<()> {
    if src.len() != dst.len() {
        return Err(onnx_runtime_ep_api::EpError::KernelFailed(format!(
            "Softmax rows: source has {} elements, destination has {}, columns={columns}; supply equal-length buffers containing complete rows",
            src.len(),
            dst.len(),
        )));
    }
    let Some(width) = super::super::checked_row_width(src.len(), columns)? else {
        return Ok(());
    };
    for (input, output) in src
        .chunks_exact(width.get())
        .zip(dst.chunks_exact_mut(width.get()))
    {
        let d = input.len();
        if d >= super::super::MIN_NEON_SOFTMAX_ROW
            && std::arch::is_aarch64_feature_detected!("neon")
        {
            // SAFETY: runtime detection; complete, disjoint rows.
            unsafe { softmax_row_impl::<true, false>(input.as_ptr(), output.as_mut_ptr(), d) };
        } else {
            // SAFETY: complete, disjoint scalar rows.
            unsafe { super::super::softmax_row_scalar(input.as_ptr(), output.as_mut_ptr(), d) };
        }
    }
    Ok(())
}

fn original(src: &[f32], dst: &mut [f32], columns: usize) {
    original_rows(src, dst, columns).unwrap();
}

#[test]
fn unrolled_rows_preserve_original_bits_and_inplace_tail_bounds() {
    super::tests::standard_fpcr();
    for d in (1..=137).chain([257, 1024, 4099]) {
        for offset in 0..4 {
            for kind in 0..5 {
                let mut input: Vec<f32> = (0..d)
                    .map(|i| ((i * 7919 % 100003) as f32 - 50001.) / 313.)
                    .collect();
                match kind {
                    1 => input[d / 2] = f32::NAN,
                    2 => input.fill(f32::NEG_INFINITY),
                    3 => input[d / 2] = f32::INFINITY,
                    4 => {
                        input.fill(-0.);
                        input[d / 2] = 0.;
                    }
                    _ => {}
                }
                let mut expected = vec![0.; d];
                original(&input, &mut expected, d);
                let mut output = vec![12345.; offset + d + 1];
                super::super::softmax_rows_serial_out_native(
                    &input,
                    &mut output[offset..offset + d],
                    d,
                )
                .unwrap();
                assert!(output[..offset].iter().all(|&x| x == 12345.));
                assert_eq!(output[offset + d], 12345.);
                assert_eq!(
                    output[offset..offset + d]
                        .iter()
                        .map(|x| x.to_bits())
                        .collect::<Vec<_>>(),
                    expected.iter().map(|x| x.to_bits()).collect::<Vec<_>>(),
                    "out-of-place d={d}, offset={offset}, kind={kind}"
                );
                output[offset..offset + d].copy_from_slice(&input);
                super::super::softmax_rows_serial_native(&mut output[offset..offset + d], d)
                    .unwrap();
                assert_eq!(
                    output[offset..offset + d]
                        .iter()
                        .map(|x| x.to_bits())
                        .collect::<Vec<_>>(),
                    expected.iter().map(|x| x.to_bits()).collect::<Vec<_>>(),
                    "in-place d={d}, offset={offset}, kind={kind}"
                );
                assert!(output[..offset].iter().all(|&x| x == 12345.));
                assert_eq!(output[offset + d], 12345.);
            }
        }
    }
}

#[cfg(feature = "mlas")]
fn cpu_ns() -> u64 {
    let mut usage = std::mem::MaybeUninit::<libc::rusage>::uninit();
    // SAFETY: getrusage writes one complete rusage on success.
    assert_eq!(
        unsafe { libc::getrusage(libc::RUSAGE_SELF, usage.as_mut_ptr()) },
        0
    );
    // SAFETY: the successful call initialized usage.
    let usage = unsafe { usage.assume_init() };
    let micros = u64::try_from(usage.ru_utime.tv_sec).unwrap() * 1_000_000
        + u64::try_from(usage.ru_utime.tv_usec).unwrap()
        + u64::try_from(usage.ru_stime.tv_sec).unwrap() * 1_000_000
        + u64::try_from(usage.ru_stime.tv_usec).unwrap();
    micros * 1000
}

#[cfg(feature = "mlas")]
#[test]
#[ignore = "CPU diagnostic; run only under the shared host flock"]
fn softmax_unroll_cpu_ab() {
    use std::{hint::black_box, time::Instant};
    let width: usize = std::env::var("NXRT_UNROLL_WIDTH").unwrap().parse().unwrap();
    let order: usize = std::env::var("NXRT_UNROLL_ORDER").unwrap().parse().unwrap();
    assert!([1, 4, 8].contains(&width));
    crate::task_runtime::set_task_thread_budget(Some(width)).unwrap();
    assert_eq!(crate::task_runtime::width(), width);
    assert!(rayon::current_thread_index().is_none() && !crate::task_runtime::in_task());
    let fpcr = super::tests::standard_fpcr();
    println!("UNROLL_FPCR,{fpcr}");
    let mut shapes = [
        (1, 4),
        (1, 7),
        (1, 8),
        (1, 16),
        (1, 257),
        (32, 1024),
        (128, 4099),
        (16, 65539),
    ];
    let rotate = order % shapes.len();
    shapes.rotate_left(rotate);
    for turn in 0..2 {
        let serial = (turn + order) % 2 == 0;
        for (n, d) in shapes {
            let source: Vec<f32> = (0..n * d)
                .map(|i| -16. + (i * 7919 % 100003) as f32 * (16. / 100002.))
                .collect();
            let mut output = vec![0.; source.len()];
            let run = |arm: usize, out: &mut [f32]| {
                let kernel: fn(&[f32], &mut [f32], usize) = match arm {
                    0 => original,
                    1 | 2 => |src, dst, d| {
                        super::super::softmax_rows_serial_out_native(src, dst, d).unwrap()
                    },
                    3 => |src, dst, d| mlas_sys::compute_softmax(src, dst, src.len() / d, d),
                    _ => unreachable!(),
                };
                let src = black_box(source.as_slice());
                if serial {
                    kernel(src, black_box(out), d);
                } else {
                    super::super::softmax_rows_with_kernel(src, black_box(out), n, d, kernel);
                }
            };
            let mut baseline = Vec::new();
            for arm in 0..4 {
                let before = crate::task_runtime::testing::counters();
                run(arm, &mut output);
                let after = crate::task_runtime::testing::counters();
                let workers = (after.tasks - before.tasks)
                    - (after.tasks_by_dispatcher - before.tasks_by_dispatcher);
                let parallel = !serial && width > 1 && super::super::fan_out_is_worthwhile(n, d);
                assert_eq!(workers > 0, parallel, "actual worker participation differs");
                if arm == 0 {
                    baseline = output.iter().map(|x| x.to_bits()).collect();
                }
                if arm == 1 || arm == 2 {
                    assert_eq!(
                        output.iter().map(|x| x.to_bits()).collect::<Vec<_>>(),
                        baseline
                    );
                }
                let mut worst = 0_f64;
                let mut hash = 0xcbf2_9ce4_8422_2325_u64;
                for (src, out) in source.chunks(d).zip(output.chunks(d)) {
                    let maximum = src.iter().copied().fold(f32::NEG_INFINITY, f32::max);
                    let sum: f64 = src
                        .iter()
                        .map(|&x| (f64::from(x) - f64::from(maximum)).exp())
                        .sum();
                    for (&x, &y) in src.iter().zip(out) {
                        let error =
                            (f64::from(y) - (f64::from(x) - f64::from(maximum)).exp() / sum).abs();
                        assert!(y.is_finite() && error <= 1e-6);
                        worst = worst.max(error);
                        hash = (hash ^ u64::from(y.to_bits())).wrapping_mul(0x100_0000_01b3);
                    }
                }
                println!("UNROLL_VALID,{width},{serial},{n},{d},{arm},{hash},{worst},{workers}");
                for _ in 0..3 {
                    run(arm, &mut output);
                }
            }
            let iters = (1_048_576 / source.len()).clamp(1, 8192);
            for rep in 0..15 {
                for slot in 0..4 {
                    let arm = (rep + slot + order) % 4;
                    // Timed work is repeated synchronous row execution, including
                    // task dispatch/join in runtime mode. CPU includes all threads;
                    // allocation, validation, tokens and I/O are outside this window.
                    let wall = Instant::now();
                    let cpu = cpu_ns();
                    for _ in 0..iters {
                        run(arm, &mut output);
                    }
                    let cpu = cpu_ns() - cpu;
                    let wall = wall.elapsed().as_nanos();
                    black_box(output.as_slice());
                    let token = [0, source.len() / 2, source.len() - 1]
                        .into_iter()
                        .fold(0xcbf2_9ce4_8422_2325_u64, |h, i| {
                            (h ^ u64::from(output[i].to_bits())).wrapping_mul(0x100_0000_01b3)
                        });
                    println!(
                        "UNROLL_SAMPLE,{width},{serial},{n},{d},{iters},{rep},{arm},{cpu},{wall},{token}"
                    );
                }
            }
        }
    }
    assert_eq!(super::tests::standard_fpcr(), fpcr);
}
