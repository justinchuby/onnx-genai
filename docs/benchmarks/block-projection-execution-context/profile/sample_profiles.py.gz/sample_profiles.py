import os,pathlib,subprocess,time,json
root=pathlib.Path('/tmp/nxrt-block-context-study');ort='/Users/justinc/Documents/GitHub/onnx-genai/target/debug/build/onnx-genai-ort-sys-14a8134a15d047e2/out/ort-prebuilt'
env=os.environ|{'ORT_ROOT':ort,'ONNX_GENAI_ORT_LIB':ort+'/lib/libonnxruntime.1.32.0.dylib','NXRT_GATHER_DENSE':'0','NXRT_BLOCK_GATED':'1','NXRT_CONSTRUCTION_WIDTH':'1','NXRT_BLOCK_MATMUL':'0'}
for label in ['baseline','candidate']:
 print('PROFILE',label,flush=True)
 with (root/(label+'-profile.stdout')).open('w') as out,(root/(label+'-profile.stderr')).open('w') as err:
  child=subprocess.Popen([str(root/(label+'.binary')),'1','64','128','163840','1',str(root/(label+'-profile.f32'))],env=env,stdout=out,stderr=err)
  try:
   time.sleep(.25)
   sampled=subprocess.run(['/usr/bin/sample',str(child.pid),'2','1','-file',str(root/(label+'-sample.txt'))],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   print(sampled.stdout[-1600:],flush=True);assert sampled.returncode==0
  finally:code=child.wait()
 assert code==0,(label,code)
print('Sampling only: instrumented process times are not benchmark evidence.',flush=True)
