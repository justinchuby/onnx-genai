//! Huge-model weight-offload mode and lightweight process-wide observability.

use std::collections::{BTreeMap, BTreeSet};
use std::ffi::OsStr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Mutex, OnceLock};

use onnx_runtime_ep_api::ExternalMmapRegion;

pub mod placement;

/// Environment switch for the route-first mmap MoE path.
pub const WEIGHT_OFFLOAD_ENV: &str = "ONNX_GENAI_WEIGHT_OFFLOAD";
/// Optional override for the Resource Governor's owned warm-host cache budget.
pub const WEIGHT_OFFLOAD_HOST_BYTES_ENV: &str = "ONNX_GENAI_WEIGHT_OFFLOAD_HOST_BYTES";
/// Opt-out switch for the route-first single-ahead expert prefetch pipeline.
///
/// The pipeline overlaps the next routed expert's host-side dequant/admission
/// (the "transfer" half of issue #87/#63) with the current expert's matmul
/// (the "compute" half). It is on by default and always produces byte-identical
/// output. To hold the host-memory cap and keep cache statistics identical to
/// the serial loop, it only engages where no host-cache eviction can occur while
/// a prefetch is in flight — a disabled host cache (`budget == 0`, pure mmap
/// streaming) or a fully-resident layer (`budget >= experts * expanded_bytes`).
/// Under an intermediate (partial-cache) budget it transparently falls back to
/// the serial route-first loop, which is byte- and stat-identical to the
/// pre-prefetch baseline. Set the variable to `0` to force the serial loop
/// unconditionally (used for A/B benchmarking and as an escape hatch).
pub const WEIGHT_OFFLOAD_PREFETCH_ENV: &str = "ONNX_GENAI_WEIGHT_OFFLOAD_PREFETCH";

/// Whether newly created QMoE kernels should pipeline route-first expert
/// prefetch. Defaults to `true`; `ONNX_GENAI_WEIGHT_OFFLOAD_PREFETCH=0` disables.
pub(crate) fn weight_offload_prefetch_default() -> bool {
    std::env::var_os(WEIGHT_OFFLOAD_PREFETCH_ENV).is_none_or(|value| value != "0")
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) struct WeightOffloadMode {
    pub enabled: bool,
}

impl WeightOffloadMode {
    pub fn from_env() -> Self {
        Self::from_value(std::env::var_os(WEIGHT_OFFLOAD_ENV).as_deref())
    }

    fn from_value(value: Option<&OsStr>) -> Self {
        Self {
            enabled: value.is_some_and(|value| value == "1"),
        }
    }
}

/// Best-effort Linux process memory/page-fault counters.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct LinuxProcessMemoryStats {
    pub resident_rss_bytes: u64,
    pub minor_faults: u64,
    pub major_faults: u64,
}

/// Snapshot of route-first weight-offload activity.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct WeightOffloadStats {
    pub mapped_bytes: u64,
    pub bytes_read_from_mmap: u64,
    pub layer_executions: u64,
    pub active_experts: u64,
    pub unique_experts_per_batch: u64,
    pub peak_dequantized_experts: u64,
    pub host_cache_hits: u64,
    pub host_cache_misses: u64,
    pub host_cache_evictions: u64,
    pub owned_host_cache_bytes: u64,
    pub peak_owned_host_cache_bytes: u64,
    /// Sum of effective cache-retention ceilings; this is not a physical Host reservation.
    pub host_cache_budget_bytes: u64,
    pub routed_tokens: u64,
    pub tokens_per_expert: BTreeMap<usize, u64>,
    pub per_layer: BTreeMap<u32, WeightOffloadLayerStats>,
    pub linux_process: Option<LinuxProcessMemoryStats>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct WeightOffloadLayerStats {
    pub executions: u64,
    pub active_experts: u64,
    pub unique_experts: u64,
    pub tokens_per_expert: BTreeMap<usize, u64>,
}

#[derive(Default)]
pub(crate) struct WeightOffloadMetrics {
    mapped_regions: Mutex<MappedRegionState>,
    bytes_read_from_mmap: AtomicU64,
    layer_executions: AtomicU64,
    active_experts: AtomicU64,
    unique_experts_per_batch: AtomicU64,
    current_dequantized_experts: AtomicU64,
    peak_dequantized_experts: AtomicU64,
    host_cache_hits: AtomicU64,
    host_cache_misses: AtomicU64,
    host_cache_evictions: AtomicU64,
    owned_host_cache_bytes: AtomicU64,
    peak_owned_host_cache_bytes: AtomicU64,
    host_cache_budget_bytes: AtomicU64,
    routed_tokens: AtomicU64,
    tokens_per_expert: Mutex<BTreeMap<usize, u64>>,
    per_layer: Mutex<BTreeMap<u32, WeightOffloadLayerStats>>,
}

#[derive(Default)]
struct MappedRegionState {
    regions: BTreeSet<ExternalMmapRegion>,
    total_bytes: u64,
}

impl WeightOffloadMetrics {
    pub fn record_mapped_regions(
        &self,
        regions: &[ExternalMmapRegion],
    ) -> Result<(), &'static str> {
        let mut state = self
            .mapped_regions
            .lock()
            .expect("weight-offload mapped-region lock poisoned");
        let mut additions = BTreeSet::new();
        let mut total = state.total_bytes;
        for &region in regions {
            let end = region
                .offset
                .checked_add(region.len)
                .ok_or("mapped region endpoint overflow")?;
            if end > isize::MAX as usize {
                return Err("mapped region endpoint exceeds isize::MAX");
            }
            if !state.regions.contains(&region) && additions.insert(region) {
                let len = u64::try_from(region.len).map_err(|_| "mapped region length overflow")?;
                total = total.checked_add(len).ok_or("mapped byte total overflow")?;
            }
        }
        state.regions.extend(additions);
        state.total_bytes = total;
        Ok(())
    }

    pub fn record_bytes_read(&self, bytes: usize) -> Result<(), &'static str> {
        let bytes = u64::try_from(bytes).map_err(|_| "mmap read byte count overflow")?;
        self.bytes_read_from_mmap
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |total| {
                total.checked_add(bytes)
            })
            .map_err(|_| "mmap read byte total overflow")?;
        Ok(())
    }

    pub fn record_dequantized_expert_materialized(&self) {
        let current = self
            .current_dequantized_experts
            .fetch_add(1, Ordering::Relaxed)
            + 1;
        self.peak_dequantized_experts
            .fetch_max(current, Ordering::Relaxed);
    }

    pub fn record_dequantized_expert_released(&self) {
        let previous = self
            .current_dequantized_experts
            .fetch_sub(1, Ordering::Relaxed);
        debug_assert!(previous > 0, "dequantized expert residency underflow");
    }

    pub fn record_host_cache_hit(&self) {
        self.host_cache_hits.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_host_cache_miss(&self) {
        self.host_cache_misses.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_host_cache_evictions(&self, count: usize) -> Result<(), &'static str> {
        let count = u64::try_from(count).map_err(|_| "host-cache eviction count overflow")?;
        self.host_cache_evictions
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |total| {
                total.checked_add(count)
            })
            .map_err(|_| "host-cache eviction total overflow")?;
        Ok(())
    }

    pub fn record_host_cache_residency(
        &self,
        previous_owned_bytes: u64,
        owned_bytes: usize,
        previous_budget_bytes: u64,
        budget_bytes: usize,
    ) -> Result<(u64, u64), &'static str> {
        let owned =
            u64::try_from(owned_bytes).map_err(|_| "owned host-cache byte count overflow")?;
        let budget =
            u64::try_from(budget_bytes).map_err(|_| "host-cache budget byte count overflow")?;

        adjust_gauge(
            &self.host_cache_budget_bytes,
            previous_budget_bytes,
            budget,
            "host-cache budget byte total overflow",
            "host-cache budget byte total underflow",
        )?;
        let aggregate_owned = match adjust_gauge(
            &self.owned_host_cache_bytes,
            previous_owned_bytes,
            owned,
            "owned host-cache byte total overflow",
            "owned host-cache byte total underflow",
        ) {
            Ok(aggregate) => aggregate,
            Err(failure) => {
                adjust_gauge(
                    &self.host_cache_budget_bytes,
                    budget,
                    previous_budget_bytes,
                    "host-cache budget rollback overflow",
                    "host-cache budget rollback underflow",
                )
                .expect("host-cache budget metric rollback must reverse the applied delta");
                return Err(failure);
            }
        };
        self.peak_owned_host_cache_bytes
            .fetch_max(aggregate_owned, Ordering::Relaxed);
        Ok((owned, budget))
    }

    pub fn release_host_cache_residency(&self, owned_bytes: u64, budget_bytes: u64) {
        subtract_gauge_saturating(&self.owned_host_cache_bytes, owned_bytes);
        subtract_gauge_saturating(&self.host_cache_budget_bytes, budget_bytes);
    }

    /// Observe one pair per distinct expert from the existing task groups.
    /// Clones must traverse the same immutable counts; the exact length is the
    /// unique-expert count. No temporary diagnostic index is needed.
    pub fn record_routes(
        &self,
        layer: u32,
        token_counts: impl ExactSizeIterator<Item = (usize, usize)> + Clone,
    ) {
        let active = token_counts
            .clone()
            .map(|(_, tokens)| tokens)
            .sum::<usize>();
        let unique = token_counts.len();
        self.layer_executions.fetch_add(1, Ordering::Relaxed);
        self.active_experts
            .fetch_add(active as u64, Ordering::Relaxed);
        self.unique_experts_per_batch
            .fetch_add(unique as u64, Ordering::Relaxed);
        self.routed_tokens
            .fetch_add(active as u64, Ordering::Relaxed);
        let mut totals = self
            .tokens_per_expert
            .lock()
            .expect("weight-offload metrics lock poisoned");
        for (expert, tokens) in token_counts.clone() {
            let total = totals.entry(expert).or_default();
            *total = total.saturating_add(tokens as u64);
        }

        drop(totals);

        let mut layers = self
            .per_layer
            .lock()
            .expect("weight-offload layer metrics lock poisoned");
        let layer_stats = layers.entry(layer).or_default();
        layer_stats.executions = layer_stats.executions.saturating_add(1);
        layer_stats.active_experts = layer_stats.active_experts.saturating_add(active as u64);
        layer_stats.unique_experts = layer_stats.unique_experts.saturating_add(unique as u64);
        for (expert, tokens) in token_counts {
            let total = layer_stats.tokens_per_expert.entry(expert).or_default();
            *total = total.saturating_add(tokens as u64);
        }
    }

    fn snapshot(&self) -> WeightOffloadStats {
        WeightOffloadStats {
            mapped_bytes: self
                .mapped_regions
                .lock()
                .expect("weight-offload mapped-region lock poisoned")
                .total_bytes,
            bytes_read_from_mmap: self.bytes_read_from_mmap.load(Ordering::Relaxed),
            layer_executions: self.layer_executions.load(Ordering::Relaxed),
            active_experts: self.active_experts.load(Ordering::Relaxed),
            unique_experts_per_batch: self.unique_experts_per_batch.load(Ordering::Relaxed),
            peak_dequantized_experts: self.peak_dequantized_experts.load(Ordering::Relaxed),
            host_cache_hits: self.host_cache_hits.load(Ordering::Relaxed),
            host_cache_misses: self.host_cache_misses.load(Ordering::Relaxed),
            host_cache_evictions: self.host_cache_evictions.load(Ordering::Relaxed),
            owned_host_cache_bytes: self.owned_host_cache_bytes.load(Ordering::Relaxed),
            peak_owned_host_cache_bytes: self.peak_owned_host_cache_bytes.load(Ordering::Relaxed),
            host_cache_budget_bytes: self.host_cache_budget_bytes.load(Ordering::Relaxed),
            routed_tokens: self.routed_tokens.load(Ordering::Relaxed),
            tokens_per_expert: self
                .tokens_per_expert
                .lock()
                .expect("weight-offload metrics lock poisoned")
                .clone(),
            per_layer: self
                .per_layer
                .lock()
                .expect("weight-offload layer metrics lock poisoned")
                .clone(),
            linux_process: linux_process_memory_stats(),
        }
    }

    #[cfg(test)]
    pub fn reset(&self) {
        *self
            .mapped_regions
            .lock()
            .expect("weight-offload mapped-region lock poisoned") = MappedRegionState::default();
        self.bytes_read_from_mmap.store(0, Ordering::Relaxed);
        self.peak_dequantized_experts.store(
            self.current_dequantized_experts.load(Ordering::Relaxed),
            Ordering::Relaxed,
        );
        self.host_cache_hits.store(0, Ordering::Relaxed);
        self.host_cache_misses.store(0, Ordering::Relaxed);
        self.host_cache_evictions.store(0, Ordering::Relaxed);
        self.owned_host_cache_bytes.store(0, Ordering::Relaxed);
        self.peak_owned_host_cache_bytes.store(0, Ordering::Relaxed);
        self.host_cache_budget_bytes.store(0, Ordering::Relaxed);
        self.layer_executions.store(0, Ordering::Relaxed);
        self.active_experts.store(0, Ordering::Relaxed);
        self.unique_experts_per_batch.store(0, Ordering::Relaxed);
        self.routed_tokens.store(0, Ordering::Relaxed);
        self.tokens_per_expert
            .lock()
            .expect("weight-offload metrics lock poisoned")
            .clear();
        self.per_layer
            .lock()
            .expect("weight-offload layer metrics lock poisoned")
            .clear();
    }
}

fn adjust_gauge(
    gauge: &AtomicU64,
    previous: u64,
    current: u64,
    overflow: &'static str,
    underflow: &'static str,
) -> Result<u64, &'static str> {
    if current >= previous {
        let delta = current - previous;
        let old = gauge
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |total| {
                total.checked_add(delta)
            })
            .map_err(|_| overflow)?;
        old.checked_add(delta).ok_or(overflow)
    } else {
        let delta = previous - current;
        let old = gauge
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |total| {
                total.checked_sub(delta)
            })
            .map_err(|_| underflow)?;
        old.checked_sub(delta).ok_or(underflow)
    }
}

fn subtract_gauge_saturating(gauge: &AtomicU64, delta: u64) {
    gauge
        .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |total| {
            Some(total.saturating_sub(delta))
        })
        .expect("saturating gauge subtraction always succeeds");
}

static METRICS: OnceLock<WeightOffloadMetrics> = OnceLock::new();

pub(crate) fn metrics() -> &'static WeightOffloadMetrics {
    METRICS.get_or_init(WeightOffloadMetrics::default)
}

/// Read current offload counters. The scheduler governor can poll this without
/// depending on kernel internals.
pub fn weight_offload_stats() -> WeightOffloadStats {
    metrics().snapshot()
}

pub(crate) fn effective_host_budget_u64(
    governor_bytes: u64,
) -> Result<u64, onnx_runtime_memory_api::MemoryError> {
    if let Some(value) = std::env::var_os(WEIGHT_OFFLOAD_HOST_BYTES_ENV) {
        let value = value
            .to_str()
            .ok_or(onnx_runtime_memory_api::MemoryError::InvalidRequest {
                tier: onnx_runtime_memory_api::Tier::Host.name(),
                requested: governor_bytes,
                reason: "host-cache byte budget is not valid UTF-8",
            })?;
        return value.parse::<u64>().map_err(|_| {
            onnx_runtime_memory_api::MemoryError::InvalidRequest {
                tier: onnx_runtime_memory_api::Tier::Host.name(),
                requested: governor_bytes,
                reason: "host-cache byte budget must be an unsigned decimal byte count",
            }
        });
    }
    Ok(governor_bytes)
}

pub(crate) fn checked_host_budget(bytes: u64) -> Result<usize, &'static str> {
    let bytes = usize::try_from(bytes).map_err(|_| "host-cache byte budget exceeds usize::MAX")?;
    if bytes > isize::MAX as usize {
        return Err("host-cache byte budget exceeds isize::MAX");
    }
    Ok(bytes)
}

#[cfg(target_os = "linux")]
fn linux_process_memory_stats() -> Option<LinuxProcessMemoryStats> {
    let status = std::fs::read_to_string("/proc/self/status").ok()?;
    let resident_rss_bytes = status
        .lines()
        .find_map(|line| line.strip_prefix("VmRSS:"))
        .and_then(|value| value.split_whitespace().next())
        .and_then(|value| value.parse::<u64>().ok())
        .and_then(|kib| kib.checked_mul(1024))
        .unwrap_or(0);

    let stat = std::fs::read_to_string("/proc/self/stat").ok()?;
    let fields = stat.get(stat.rfind(')')?.checked_add(2)?..)?;
    let fields = fields.split_whitespace().collect::<Vec<_>>();
    Some(LinuxProcessMemoryStats {
        resident_rss_bytes,
        minor_faults: fields.get(7)?.parse().ok()?,
        major_faults: fields.get(9)?.parse().ok()?,
    })
}

#[cfg(not(target_os = "linux"))]
fn linux_process_memory_stats() -> Option<LinuxProcessMemoryStats> {
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn weight_offload_flag_is_opt_in() {
        assert!(!WeightOffloadMode::from_value(None).enabled);
        assert!(!WeightOffloadMode::from_value(Some(OsStr::new("0"))).enabled);
        assert!(WeightOffloadMode::from_value(Some(OsStr::new("1"))).enabled);
    }

    #[test]
    fn host_cache_budget_rejects_unaddressable_values() {
        if usize::BITS == 64 {
            assert_eq!(
                checked_host_budget(isize::MAX as u64 + 1),
                Err("host-cache byte budget exceeds isize::MAX")
            );
        }
    }

    #[test]
    fn derived_route_counts_preserve_global_and_layer_snapshots() {
        let metrics = WeightOffloadMetrics::default();
        let first = BTreeMap::from([(2, vec![(); 3]), (9, vec![(); 1])]);
        let second = BTreeMap::from([(2, vec![(); 1]), (7, vec![(); 2])]);
        let third = BTreeMap::from([(9, vec![(); 4])]);
        let empty = BTreeMap::<usize, Vec<()>>::new();
        for (layer, groups) in [(5, &first), (5, &second), (8, &third), (8, &empty)] {
            metrics.record_routes(
                layer,
                groups.iter().map(|(&expert, rows)| (expert, rows.len())),
            );
        }
        let actual = metrics.snapshot();
        let expected = WeightOffloadStats {
            layer_executions: 4,
            active_experts: 11,
            unique_experts_per_batch: 5,
            routed_tokens: 11,
            tokens_per_expert: BTreeMap::from([(2, 4), (7, 2), (9, 5)]),
            per_layer: BTreeMap::from([
                (
                    5,
                    WeightOffloadLayerStats {
                        executions: 2,
                        active_experts: 7,
                        unique_experts: 4,
                        tokens_per_expert: BTreeMap::from([(2, 4), (7, 2), (9, 1)]),
                    },
                ),
                (
                    8,
                    WeightOffloadLayerStats {
                        executions: 2,
                        active_experts: 4,
                        unique_experts: 1,
                        tokens_per_expert: BTreeMap::from([(9, 4)]),
                    },
                ),
            ]),
            // Best-effort process counters are independent of route accounting.
            linux_process: actual.linux_process,
            ..WeightOffloadStats::default()
        };
        assert_eq!(actual, expected);
    }

    #[test]
    fn route_metrics_keep_zero_members_and_saturating_per_layer_totals() {
        let metrics = WeightOffloadMetrics::default();
        metrics
            .tokens_per_expert
            .lock()
            .unwrap()
            .insert(3, u64::MAX - 1);
        metrics.per_layer.lock().unwrap().insert(
            7,
            WeightOffloadLayerStats {
                executions: u64::MAX - 1,
                active_experts: u64::MAX - 2,
                unique_experts: u64::MAX - 1,
                tokens_per_expert: BTreeMap::from([(3, u64::MAX - 1)]),
            },
        );
        metrics.record_routes(7, [(3, 3), (9, 0)].into_iter());
        let actual = metrics.snapshot();
        let expected = WeightOffloadStats {
            layer_executions: 1,
            active_experts: 3,
            unique_experts_per_batch: 2,
            routed_tokens: 3,
            tokens_per_expert: BTreeMap::from([(3, u64::MAX), (9, 0)]),
            per_layer: BTreeMap::from([(
                7,
                WeightOffloadLayerStats {
                    executions: u64::MAX,
                    active_experts: u64::MAX,
                    unique_experts: u64::MAX,
                    tokens_per_expert: BTreeMap::from([(3, u64::MAX), (9, 0)]),
                },
            )]),
            linux_process: actual.linux_process,
            ..WeightOffloadStats::default()
        };
        assert_eq!(actual, expected);
    }

    #[test]
    fn mapped_bytes_sum_distinct_ranges_across_layers() {
        let metrics = WeightOffloadMetrics::default();
        let first = ExternalMmapRegion {
            mapping_id: 7,
            offset: 0,
            len: 100,
        };
        let second = ExternalMmapRegion {
            mapping_id: 7,
            offset: 100,
            len: 200,
        };
        metrics.record_mapped_regions(&[first]).unwrap();
        metrics.record_mapped_regions(&[second, first]).unwrap();
        assert_eq!(metrics.snapshot().mapped_bytes, 300);
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn linux_process_counters_are_best_effort_readable() {
        let stats = linux_process_memory_stats().expect("Linux /proc process counters");
        assert!(stats.resident_rss_bytes > 0);
    }
}


#[cfg(test)]
impl WeightOffloadMetrics {
    fn reference_record_routes(&self, layer: u32, token_counts: &BTreeMap<usize, usize>) {
        let active = token_counts.values().copied().sum::<usize>();
        self.layer_executions.fetch_add(1, Ordering::Relaxed);
        self.active_experts
            .fetch_add(active as u64, Ordering::Relaxed);
        self.unique_experts_per_batch
            .fetch_add(token_counts.len() as u64, Ordering::Relaxed);
        self.routed_tokens
            .fetch_add(active as u64, Ordering::Relaxed);
        let mut totals = self
            .tokens_per_expert
            .lock()
            .expect("weight-offload metrics lock poisoned");
        for (&expert, &tokens) in token_counts {
            let total = totals.entry(expert).or_default();
            *total = total.saturating_add(tokens as u64);
        }

        drop(totals);

        let mut layers = self
            .per_layer
            .lock()
            .expect("weight-offload layer metrics lock poisoned");
        let layer_stats = layers.entry(layer).or_default();
        layer_stats.executions = layer_stats.executions.saturating_add(1);
        layer_stats.active_experts = layer_stats.active_experts.saturating_add(active as u64);
        layer_stats.unique_experts = layer_stats
            .unique_experts
            .saturating_add(token_counts.len() as u64);
        for (&expert, &tokens) in token_counts {
            let total = layer_stats.tokens_per_expert.entry(expert).or_default();
            *total = total.saturating_add(tokens as u64);
        }
    }

}

#[cfg(test)]
mod route_count_allocation_probe {
    use super::*;
    use crate::group_allocation_probe::observed;
    fn compare(a: &WeightOffloadMetrics, b: &WeightOffloadMetrics, active: usize, unique: usize) {
        let mut actual=a.snapshot();let expected=b.snapshot();
        actual.linux_process=expected.linux_process;
        assert_eq!(actual,expected);
        assert_eq!(actual.layer_executions,2049);
        assert_eq!(actual.active_experts,2049*active as u64);
        assert_eq!(actual.routed_tokens,2049*active as u64);
        assert_eq!(actual.unique_experts_per_batch,2049*unique as u64);
    }
    #[test]
    fn route_statistics_borrow_existing_groups_without_temporary_counts() {
        let positive=observed(||drop(std::hint::black_box(Box::new([3u8;1024]))));
        assert!(positive.0>0 && positive.1>0);
        println!("CONTROL allocations={} frees={}",positive.0,positive.1);
        for experts in [1usize,7,65] {
            for rows in [1usize,8,64] {
                let mut ks=vec![1,experts.min(3)];ks.dedup();
                for k in ks {
                    let events:Vec<_>=(0..rows).flat_map(|r|(0..k).map(move |rank|(r+k-1-rank)%experts)).collect();
                    let mut tasks=BTreeMap::<usize,Vec<(usize,usize,f32)>>::new();
                    let mut prime=BTreeMap::new();
                    for (slot,&e) in events.iter().enumerate(){
                        tasks.entry(e).or_default().push((slot/k,slot,1.));
                        *prime.entry(e).or_insert(0usize)+=1;
                    }
                    let baseline=WeightOffloadMetrics::default();
                    let candidate=WeightOffloadMetrics::default();
                    baseline.reference_record_routes(77,&prime);
                    candidate.record_routes(77,tasks.iter().map(|(&e,t)|(e,t.len())));
                    let old=observed(||{
                        for _ in 0..2048 {
                            let mut counts=BTreeMap::new();
                            for &e in &events{*counts.entry(e).or_insert(0usize)+=1;}
                            baseline.reference_record_routes(77,&counts);
                            std::hint::black_box(&counts);
                        }
                    });
                    let new=observed(||{
                        for _ in 0..2048 {
                            candidate.record_routes(77,tasks.iter().map(|(&e,t)|(e,t.len())));
                        }
                    });
                    assert!(old.0>0 && old.0==old.1);assert_eq!(new,(0,0));
                    compare(&baseline,&candidate,events.len(),tasks.len());
                    println!("CASE experts={experts} rows={rows} k={k} active={} unique={} calls=2048 baseline_alloc={} baseline_free={} candidate_alloc={} candidate_free={}",events.len(),tasks.len(),old.0,old.1,new.0,new.1);
                }
            }
        }
    }
}
